using UnityEngine;

// This class controls the player's movement and interactions.
public class PlayerStealthController : MonoBehaviour
{
    [Tooltip("The speed at which the player moves.")]
    public float moveSpeed = 5f;

    private Rigidbody2D rb;
    private Vector2 moveInput;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Get both horizontal and vertical input.
        moveInput.x = Input.GetAxisRaw("Horizontal");
        moveInput.y = Input.GetAxisRaw("Vertical");
    }

    void FixedUpdate()
    {
        // Apply velocity to move the player. We normalize the input to prevent faster diagonal movement.
        rb.velocity = moveInput.normalized * moveSpeed;
    }

    // This function is called by Unity when the player's collider overlaps with another trigger collider.
    void OnTriggerEnter2D(Collider2D other)
    {
        // Check if the object we collided with is a "Gem".
        if (other.gameObject.CompareTag("Gem"))
        {
            // Find the Game Manager and tell it a gem was collected.
            GameInitializerStealth.instance.CollectGem();
            
            // Destroy the gem object.
            Destroy(other.gameObject);
        }
    }
}
