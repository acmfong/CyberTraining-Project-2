using UnityEngine;
using UnityEngine.UI;

// This script automatically sets up the entire game scene and manages game state.
public class GameInitializerStealth : MonoBehaviour
{
    public static GameInitializerStealth instance;

    private int gemsToCollect = 0;
    private Text gemsText;

    void Awake()
    {
        if (instance == null) instance = this;
        else Destroy(gameObject);

        Camera.main.backgroundColor = new Color(0.2f, 0.2f, 0.2f);
        CreateUI();
        CreateWalls();
        CreateGems();
        CreatePlayer();
        CreateGuard();
    }

    void CreatePlayer()
    {
        GameObject player = new GameObject("Player");
        player.tag = "Player";
        player.transform.position = new Vector3(-7, 3, 0);
        player.AddComponent<PlayerStealthController>();
        player.AddComponent<SpriteRenderer>().color = Color.cyan;
        player.AddComponent<Rigidbody2D>().gravityScale = 0;
        player.AddComponent<BoxCollider2D>().isTrigger = true; // For collecting gems
        player.AddComponent<CircleCollider2D>(); // For physical collision
    }

    void CreateGuard()
    {
        GameObject guard = new GameObject("Guard");
        guard.transform.position = new Vector3(7, -3, 0);
        
        // Create patrol points for the guard to follow
        Transform[] patrolPoints = new Transform[2];
        GameObject p1 = new GameObject("PatrolPoint1");
        p1.transform.position = new Vector3(7, -3, 0);
        patrolPoints[0] = p1.transform;

        GameObject p2 = new GameObject("PatrolPoint2");
        p2.transform.position = new Vector3(-7, -3, 0);
        patrolPoints[1] = p2.transform;

        GuardAIController controller = guard.AddComponent<GuardAIController>();
        controller.patrolPoints = patrolPoints;
        controller.visionObstacleMask = LayerMask.GetMask("Walls");

        guard.AddComponent<SpriteRenderer>().color = Color.red;
        guard.AddComponent<Rigidbody2D>().gravityScale = 0;
        guard.AddComponent<BoxCollider2D>();
    }

    void CreateWalls()
    {
        // Create a container for walls to keep the hierarchy clean
        GameObject wallContainer = new GameObject("Walls");
        int wallLayer = LayerMask.NameToLayer("Walls");

        // Top and Bottom Walls
        CreateWall(wallContainer, "Wall_TB", new Vector3(0, 5, 0), new Vector3(20, 1, 1), wallLayer);
        CreateWall(wallContainer, "Wall_TB", new Vector3(0, -5, 0), new Vector3(20, 1, 1), wallLayer);
        // Left and Right Walls
        CreateWall(wallContainer, "Wall_LR", new Vector3(-10, 0, 0), new Vector3(1, 10, 1), wallLayer);
        CreateWall(wallContainer, "Wall_LR", new Vector3(10, 0, 0), new Vector3(1, 10, 1), wallLayer);
        // Center Obstacle
        CreateWall(wallContainer, "Wall_Center", new Vector3(0, 0, 0), new Vector3(5, 2, 1), wallLayer);
    }

    void CreateWall(GameObject parent, string name, Vector3 position, Vector3 scale, int layer)
    {
        GameObject wall = new GameObject(name);
        wall.transform.SetParent(parent.transform);
        wall.transform.position = position;
        wall.transform.localScale = scale;
        wall.AddComponent<SpriteRenderer>().color = Color.gray;
        wall.AddComponent<BoxCollider2D>();
        wall.layer = layer;
    }
    
    void CreateGems()
    {
        CreateGem(new Vector3(0, 3, 0));
        CreateGem(new Vector3(8, 0, 0));
        CreateGem(new Vector3(-8, 0, 0));
    }

    void CreateGem(Vector3 position)
    {
        GameObject gem = new GameObject("Gem");
        gem.tag = "Gem";
        gem.transform.position = position;
        gem.AddComponent<SpriteRenderer>().color = Color.yellow;
        gem.AddComponent<CircleCollider2D>().isTrigger = true;
        gemsToCollect++;
        UpdateGemsText();
    }

    void CreateUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>();
        canvasObj.AddComponent<GraphicRaycaster>();

        GameObject textObj = new GameObject("GemsText");
        textObj.transform.SetParent(canvasObj.transform);

        gemsText = textObj.AddComponent<Text>();
        gemsText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        gemsText.fontSize = 28;
        gemsText.color = Color.white;
        gemsText.alignment = TextAnchor.UpperLeft;

        RectTransform rectTransform = gemsText.GetComponent<RectTransform>();
        rectTransform.anchorMin = new Vector2(0, 1);
        rectTransform.anchorMax = new Vector2(0, 1);
        rectTransform.pivot = new Vector2(0, 1);
        rectTransform.anchoredPosition = new Vector2(10, -10);
    }

    public void CollectGem()
    {
        gemsToCollect--;
        UpdateGemsText();
        if (gemsToCollect <= 0)
        {
            gemsText.text = "YOU WIN!";
            // Optionally, freeze the game here
            Time.timeScale = 0;
        }
    }

    void UpdateGemsText()
    {
        gemsText.text = "Gems Left: " + gemsToCollect;
    }
}
