using UnityEngine;
using UnityEngine.SceneManagement;

// This class controls the AI Guard's behavior using a Finite State Machine.
public class GuardAIController : MonoBehaviour
{
    // --- Public AI Settings ---
    [Header("AI Settings")]
    public float patrolSpeed = 2f;
    public float chaseSpeed = 4f;
    public float visionAngle = 45f; // The half-angle of the vision cone
    public float visionDistance = 8f;
    public LayerMask visionObstacleMask; // Layers that block vision (e.g., "Walls")
    public Transform[] patrolPoints;

    // --- Private State Variables ---
    public enum AIState { Patrolling, Chasing }
    private AIState currentState;
    private Transform playerTransform;
    private int currentPatrolIndex = 0;

    void Start()
    {
        currentState = AIState.Patrolling;
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Update()
    {
        // The core of the FSM: execute behavior based on the current state.
        switch (currentState)
        {
            case AIState.Patrolling:
                Patrol();
                break;
            case AIState.Chasing:
                Chase();
                break;
        }

        // Always check if we can see the player, which might trigger a state change.
        CheckForPlayerInVision();
    }

    void Patrol()
    {
        // If we don't have patrol points, do nothing.
        if (patrolPoints.Length == 0) return;

        // Move towards the current patrol point.
        transform.position = Vector2.MoveTowards(transform.position, patrolPoints[currentPatrolIndex].position, patrolSpeed * Time.deltaTime);

        // If we reach the patrol point, target the next one.
        if (Vector2.Distance(transform.position, patrolPoints[currentPatrolIndex].position) < 0.1f)
        {
            currentPatrolIndex = (currentPatrolIndex + 1) % patrolPoints.Length;
        }
    }

    void Chase()
    {
        // Move directly towards the player.
        transform.position = Vector2.MoveTowards(transform.position, playerTransform.position, chaseSpeed * Time.deltaTime);
    }

    void CheckForPlayerInVision()
    {
        if (playerTransform == null) return;

        Vector2 directionToPlayer = (playerTransform.position - transform.position).normalized;

        // Check if the player is within the vision angle.
        if (Vector2.Angle(transform.right, directionToPlayer) < visionAngle)
        {
            // Check if the player is within vision distance.
            float distanceToPlayer = Vector2.Distance(transform.position, playerTransform.position);
            if (distanceToPlayer < visionDistance)
            {
                // Check if the line of sight is blocked by an obstacle.
                if (!Physics2D.Raycast(transform.position, directionToPlayer, distanceToPlayer, visionObstacleMask))
                {
                    // If all checks pass, we see the player! Change state to Chasing.
                    currentState = AIState.Chasing;
                    return; // Exit the function early
                }
            }
        }
        
        // If we can't see the player, go back to patrolling.
        currentState = AIState.Patrolling;
    }

    // This function is called when the Guard collides with another object.
    void OnCollisionEnter2D(Collision2D collision)
    {
        // If we are chasing and we hit the player, restart the game.
        if (currentState == AIState.Chasing && collision.gameObject.CompareTag("Player"))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    // This helps visualize the vision cone in the editor.
    void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, visionDistance);

        Vector3 fovLine1 = Quaternion.AngleAxis(visionAngle, Vector3.forward) * transform.right * visionDistance;
        Vector3 fovLine2 = Quaternion.AngleAxis(-visionAngle, Vector3.forward) * transform.right * visionDistance;

        Gizmos.color = Color.blue;
        Gizmos.DrawRay(transform.position, fovLine1);
        Gizmos.DrawRay(transform.position, fovLine2);

        if (currentState == AIState.Chasing)
        {
            Gizmos.color = Color.red;
            if(playerTransform != null) Gizmos.DrawLine(transform.position, playerTransform.position);
        }
    }
}
