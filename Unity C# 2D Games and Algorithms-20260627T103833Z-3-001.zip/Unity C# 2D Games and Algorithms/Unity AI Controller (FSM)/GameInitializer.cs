using UnityEngine;

// This script automatically sets up the game scene (Player, AI, and Ground) when the game starts.
public class GameInitializer : MonoBehaviour
{
    void Awake()
    {
        int groundLayerValue = LayerMask.NameToLayer("Ground");
        if (groundLayerValue == -1)
        {
            Debug.LogError("Please create a new Layer named 'Ground' in the Unity Editor (Edit -> Project Settings -> Tags and Layers).");
            return;
        }
        LayerMask groundLayerMask = LayerMask.GetMask("Ground");

        CreateGround(groundLayerValue);
        CreatePlayer(groundLayerMask);
        CreateAICharacter(groundLayerMask);
    }

    void CreateGround(int layer)
    {
        GameObject ground = new GameObject("Ground");
        ground.transform.position = new Vector3(0, -3, 0);
        ground.transform.localScale = new Vector3(20, 1, 1);
        ground.layer = layer;
        SpriteRenderer groundSprite = ground.AddComponent<SpriteRenderer>();
        groundSprite.color = Color.white;
        ground.AddComponent<BoxCollider2D>();
    }

    void CreatePlayer(LayerMask groundLayer)
    {
        GameObject player = new GameObject("Player");
        player.transform.position = new Vector3(-4, 0, 0);
        SpriteRenderer playerSprite = player.AddComponent<SpriteRenderer>();
        playerSprite.color = Color.blue;
        player.AddComponent<Rigidbody2D>();
        player.AddComponent<BoxCollider2D>();

        GameObject groundCheck = new GameObject("GroundCheck");
        groundCheck.transform.SetParent(player.transform);
        groundCheck.transform.localPosition = new Vector3(0, -0.5f, 0);

        PlayerController playerController = player.AddComponent<PlayerController>();
        playerController.groundCheck = groundCheck.transform;
        playerController.groundLayer = groundLayer;
    }

    void CreateAICharacter(LayerMask groundLayer)
    {
        GameObject ai = new GameObject("AI_Character");
        ai.transform.position = new Vector3(4, -2, 0);
        SpriteRenderer aiSprite = ai.AddComponent<SpriteRenderer>();
        aiSprite.color = Color.red;
        ai.AddComponent<Rigidbody2D>();
        ai.AddComponent<BoxCollider2D>();

        GameObject wallCheck = new GameObject("WallCheck");
        wallCheck.transform.SetParent(ai.transform);
        wallCheck.transform.localPosition = new Vector3(0.5f, 0, 0);

        GameObject edgeCheck = new GameObject("EdgeCheck");
        edgeCheck.transform.SetParent(ai.transform);
        edgeCheck.transform.localPosition = new Vector3(0.5f, -0.5f, 0);

        AIController aiController = ai.AddComponent<AIController>();
        aiController.wallCheck = wallCheck.transform;
        aiController.edgeCheck = edgeCheck.transform;
        aiController.groundLayer = groundLayer;
    }
}
