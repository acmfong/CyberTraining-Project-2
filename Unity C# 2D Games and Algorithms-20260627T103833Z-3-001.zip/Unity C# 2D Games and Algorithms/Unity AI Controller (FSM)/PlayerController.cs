using UnityEngine;

// This class controls the player's movement and actions in a 2D environment.
public class PlayerController : MonoBehaviour
{
    // --- Player Movement ---
    [Header("Movement")]
    [Tooltip("The speed at which the player moves horizontally.")]
    public float moveSpeed = 5f;
    [Tooltip("The force applied to the player when they jump.")]
    public float jumpForce = 10f;

    // --- Ground Check ---
    [Header("Ground Check")]
    [Tooltip("The transform representing the position to check for ground from.")]
    public Transform groundCheck;
    [Tooltip("The radius of the circle used to check for ground.")]
    public float groundCheckRadius = 0.2f;
    [Tooltip("The layer(s) that are considered 'ground' for the player.")]
    public LayerMask groundLayer;

    // --- Private Variables ---
    private Rigidbody2D rb;
    private bool isGrounded;
    private float moveInput;

    // Start is called before the first frame update
    void Start()
    {
        // Get the Rigidbody2D component attached to this GameObject.
        rb = GetComponent<Rigidbody2D>();
        if (rb == null)
        {
            Debug.LogError("PlayerController requires a Rigidbody2D component.");
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Get horizontal input (A/D keys or Left/Right arrow keys).
        moveInput = Input.GetAxis("Horizontal");

        // Check if the player is touching the ground layer.
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        // If the jump button (Spacebar) is pressed and the player is grounded...
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            // Apply an upward force to make the player jump.
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }
    }

    // FixedUpdate is used for physics calculations.
    void FixedUpdate()
    {
        // Apply velocity to move the player horizontally.
        rb.velocity = new Vector2(moveInput * moveSpeed, rb.velocity.y);
    }
}
using UnityEngine;

// This class controls the player's movement and actions in a 2D environment.
public class PlayerController : MonoBehaviour
{
    // --- Player Movement ---
    [Header("Movement")]
    [Tooltip("The speed at which the player moves horizontally.")]
    public float moveSpeed = 5f;
    [Tooltip("The force applied to the player when they jump.")]
    public float jumpForce = 10f;

    // --- Ground Check ---
    [Header("Ground Check")]
    [Tooltip("The transform representing the position to check for ground from.")]
    public Transform groundCheck;
    [Tooltip("The radius of the circle used to check for ground.")]
    public float groundCheckRadius = 0.2f;
    [Tooltip("The layer(s) that are considered 'ground' for the player.")]
    public LayerMask groundLayer;

    // --- Private Variables ---
    private Rigidbody2D rb;
    private bool isGrounded;
    private float moveInput;

    // Start is called before the first frame update
    void Start()
    {
        // Get the Rigidbody2D component attached to this GameObject.
        rb = GetComponent<Rigidbody2D>();
        if (rb == null)
        {
            Debug.LogError("PlayerController requires a Rigidbody2D component.");
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Get horizontal input (A/D keys or Left/Right arrow keys).
        moveInput = Input.GetAxis("Horizontal");

        // Check if the player is touching the ground layer.
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        // If the jump button (Spacebar) is pressed and the player is grounded...
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            // Apply an upward force to make the player jump.
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }
    }

    // FixedUpdate is used for physics calculations.
    void FixedUpdate()
    {
        // Apply velocity to move the player horizontally.
        rb.velocity = new Vector2(moveInput * moveSpeed, rb.velocity.y);
    }
}
