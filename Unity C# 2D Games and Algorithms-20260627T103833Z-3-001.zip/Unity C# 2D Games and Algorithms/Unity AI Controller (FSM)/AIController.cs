using UnityEngine;

// This class controls an AI character using a simple Finite State Machine (FSM).
// The AI will patrol left and right, turning around when it detects a wall or an edge.
public class AIController : MonoBehaviour
{
    // --- AI Movement ---
    [Header("Movement")]
    [Tooltip("The speed at which the AI moves horizontally.")]
    public float moveSpeed = 2f;

    // --- AI Detection ---
    [Header("Detection")]
    [Tooltip("The transform representing the position to check for walls from.")]
    public Transform wallCheck;
    [Tooltip("The transform representing the position to check for edges from.")]
    public Transform edgeCheck;
    [Tooltip("The distance of the raycast used to check for walls.")]
    public float wallCheckDistance = 0.5f;
    [Tooltip("The layer(s) that are considered 'ground' or obstacles.")]
    public LayerMask groundLayer;


    // --- Private Variables ---
    private Rigidbody2D rb;
    private bool movingRight = true;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        if (rb == null)
        {
            Debug.LogError("AIController requires a Rigidbody2D component.");
        }
    }

    // FixedUpdate is called at a fixed interval and is used for physics calculations.
    void FixedUpdate()
    {
        rb.velocity = new Vector2(movingRight ? moveSpeed : -moveSpeed, rb.velocity.y);

        if (IsNearWall() || IsAtEdge())
        {
            TurnAround();
        }
    }

    private bool IsNearWall()
    {
        Vector2 direction = movingRight ? Vector2.right : Vector2.left;
        RaycastHit2D hit = Physics2D.Raycast(wallCheck.position, direction, wallCheckDistance, groundLayer);
        return hit.collider != null;
    }

    private bool IsAtEdge()
    {
        RaycastHit2D hit = Physics2D.Raycast(edgeCheck.position, Vector2.down, 1f, groundLayer);
        return hit.collider == null;
    }

    private void TurnAround()
    {
        movingRight = !movingRight;
        Vector3 newScale = transform.localScale;
        newScale.x *= -1;
        transform.localScale = newScale;
    }
}
