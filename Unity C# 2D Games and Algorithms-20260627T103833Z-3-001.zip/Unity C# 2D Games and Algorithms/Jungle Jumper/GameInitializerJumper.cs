using UnityEngine;
using UnityEngine.UI;

// This script automatically sets up the game and manages the level generation and UI.
public class GameInitializerJumper : MonoBehaviour
{
    private Transform playerTransform;
    private Text scoreText;
    private float highestPoint = 0f;
    private float nextPlatformY = 0f;

    void Awake()
    {
        Camera.main.backgroundColor = Color.cyan;
        CreatePlayer();
        CreateUI();
        
        // Create the initial set of platforms.
        for (int i = 0; i < 10; i++)
        {
            SpawnPlatform();
        }
    }

    void Update()
    {
        if (playerTransform == null) return;

        // Generate new platforms as the player climbs.
        if (playerTransform.position.y > nextPlatformY - 15)
        {
            SpawnPlatform();
        }

        // Update the score based on the highest point reached.
        if (playerTransform.position.y > highestPoint)
        {
            highestPoint = playerTransform.position.y;
            scoreText.text = "Height: " + Mathf.RoundToInt(highestPoint * 2);
        }
    }

    void CreatePlayer()
    {
        GameObject player = new GameObject("Player");
        player.transform.position = new Vector3(0, 1, 0);
        player.AddComponent<PlayerJumperController>();
        player.AddComponent<SpriteRenderer>().color = new Color(1, 0.5f, 0); // Orange color
        player.AddComponent<Rigidbody2D>();
        player.AddComponent<BoxCollider2D>();
        playerTransform = player.transform;

        // Attach the camera follow script to the main camera.
        Camera.main.gameObject.AddComponent<CameraFollow>().target = playerTransform;
    }

    void SpawnPlatform()
    {
        float randomX = Random.Range(-4f, 4f);
        Vector3 platformPosition = new Vector3(randomX, nextPlatformY, 0);

        GameObject platform = new GameObject("Platform");
        platform.tag = "Platform";
        platform.transform.position = platformPosition;
        platform.AddComponent<SpriteRenderer>().color = Color.green;
        BoxCollider2D collider = platform.AddComponent<BoxCollider2D>();
        collider.size = new Vector2(2f, 0.5f);
        platform.transform.localScale = new Vector3(2f, 0.5f, 1f);

        // Set the height for the next platform.
        nextPlatformY += Random.Range(2f, 4f);
    }

    void CreateUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>();
        canvasObj.AddComponent<GraphicRaycaster>();

        GameObject textObj = new GameObject("ScoreText");
        textObj.transform.SetParent(canvasObj.transform);

        scoreText = textObj.AddComponent<Text>();
        scoreText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        scoreText.fontSize = 28;
        scoreText.color = Color.black;
        scoreText.alignment = TextAnchor.UpperCenter;

        RectTransform rectTransform = scoreText.GetComponent<RectTransform>();
        rectTransform.anchorMin = new Vector2(0.5f, 1);
        rectTransform.anchorMax = new Vector2(0.5f, 1);
        rectTransform.pivot = new Vector2(0.5f, 1);
        rectTransform.anchoredPosition = new Vector2(0, -10);
        scoreText.text = "Height: 0";
    }
}
