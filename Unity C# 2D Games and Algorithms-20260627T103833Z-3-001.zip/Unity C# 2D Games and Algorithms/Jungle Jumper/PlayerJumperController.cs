using UnityEngine;
using UnityEngine.SceneManagement;

// This class controls the player's movement and jumping behavior.
public class PlayerJumperController : MonoBehaviour
{
    [Tooltip("The speed at which the player moves horizontally.")]
    public float moveSpeed = 8f;
    [Tooltip("The force applied to the player when they jump.")]
    public float jumpForce = 15f;

    private Rigidbody2D rb;
    private float moveInput;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Get horizontal input (A/D keys or Left/Right arrow keys).
        moveInput = Input.GetAxis("Horizontal");

        // If the player falls off the bottom of the screen, restart the game.
        if (transform.position.y < Camera.main.transform.position.y - 6f)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    void FixedUpdate()
    {
        // Apply velocity to move the player horizontally.
        rb.velocity = new Vector2(moveInput * moveSpeed, rb.velocity.y);
    }

    // This function is called by Unity when the player collides with another object.
    void OnCollisionEnter2D(Collision2D collision)
    {
        // Check if the object we collided with is a "Platform".
        if (collision.gameObject.CompareTag("Platform"))
        {
            // Check if we are moving downwards (landing, not hitting from the side).
            if (rb.velocity.y <= 0)
            {
                // Apply an upward force to make the player jump.
                rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            }
        }
    }
}
