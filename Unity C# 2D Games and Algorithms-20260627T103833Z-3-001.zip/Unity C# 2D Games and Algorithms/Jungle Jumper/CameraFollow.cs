using UnityEngine;

// This class makes the camera follow a target (the player) vertically.
public class CameraFollow : MonoBehaviour
{
    [Tooltip("The target object for the camera to follow.")]
    public Transform target;

    void LateUpdate()
    {
        // If the target exists and is higher than the camera, move the camera up.
        if (target != null && target.position.y > transform.position.y)
        {
            transform.position = new Vector3(transform.position.x, target.position.y, transform.position.z);
        }
    }
}
