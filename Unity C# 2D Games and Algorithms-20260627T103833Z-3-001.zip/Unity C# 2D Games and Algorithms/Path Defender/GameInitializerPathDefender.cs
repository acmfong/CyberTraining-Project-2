using UnityEngine;

// This script automatically sets up the entire game scene.
public class GameInitializerPathDefender : MonoBehaviour
{
    public GameObject towerPrefab;
    public GameObject enemyPrefab;
    private Transform[] pathWaypoints;

    void Awake()
    {
        Camera.main.backgroundColor = new Color(0.2f, 0.5f, 0.2f); // Green field color
        CreatePath();
        CreatePrefabs();
        
        // Pass the waypoints to the static variable in the EnemyController.
        EnemyController.waypoints = pathWaypoints;

        // Start spawning enemies.
        InvokeRepeating("SpawnEnemy", 2f, 1.5f);
    }

    void Update()
    {
        // Check for player input to place a tower.
        if (Input.GetMouseButtonDown(0))
        {
            PlaceTower();
        }
    }

    void CreatePath()
    {
        GameObject pathContainer = new GameObject("Path");
        pathWaypoints = new Transform[4];

        pathWaypoints[0] = CreateWaypoint(pathContainer, new Vector3(-12, 0, 0));
        pathWaypoints[1] = CreateWaypoint(pathContainer, new Vector3(-6, 0, 0));
        pathWaypoints[2] = CreateWaypoint(pathContainer, new Vector3(-6, 4, 0));
        pathWaypoints[3] = CreateWaypoint(pathContainer, new Vector3(8, 4, 0));
    }

    Transform CreateWaypoint(GameObject parent, Vector3 position)
    {
        GameObject waypoint = new GameObject("Waypoint");
        waypoint.transform.position = position;
        waypoint.transform.SetParent(parent.transform);
        // Add a visual for the path in the editor
        waypoint.AddComponent<SpriteRenderer>().color = new Color(0.6f, 0.4f, 0.2f, 0.5f);
        return waypoint.transform;
    }

    void CreatePrefabs()
    {
        // --- Tower Prefab ---
        towerPrefab = new GameObject("TowerPrefab");
        towerPrefab.AddComponent<SpriteRenderer>().color = Color.green;
        towerPrefab.AddComponent<TowerController>();
        towerPrefab.GetComponent<TowerController>().projectilePrefab = CreateProjectilePrefab();
        towerPrefab.SetActive(false);

        // --- Enemy Prefab ---
        enemyPrefab = new GameObject("EnemyPrefab");
        enemyPrefab.tag = "Enemy";
        enemyPrefab.AddComponent<SpriteRenderer>().color = Color.red;
        enemyPrefab.AddComponent<EnemyController>();
        enemyPrefab.AddComponent<BoxCollider2D>();
        enemyPrefab.SetActive(false);
    }

    GameObject CreateProjectilePrefab()
    {
        GameObject prefab = new GameObject("ProjectilePrefab");
        prefab.AddComponent<SpriteRenderer>().color = Color.yellow;
        prefab.transform.localScale = new Vector3(0.3f, 0.3f, 1f);
        prefab.AddComponent<ProjectileController>();
        prefab.SetActive(false);
        return prefab;
    }

    void SpawnEnemy()
    {
        // Instantiate an enemy at the first waypoint.
        Instantiate(enemyPrefab, pathWaypoints[0].position, Quaternion.identity).SetActive(true);
    }

    void PlaceTower()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);
        
        // Instantiate a new tower at the mouse position.
        Instantiate(towerPrefab, mousePos2D, Quaternion.identity).SetActive(true);
    }
}
