using UnityEngine;

// This class controls the projectile's movement and collision.
public class ProjectileController : MonoBehaviour
{
    public float speed = 15f;
    private Transform target;

    public void Seek(Transform _target)
    {
        target = _target;
    }

    void Update()
    {
        if (target == null)
        {
            Destroy(gameObject);
            return;
        }

        Vector2 dir = target.position - transform.position;
        float distanceThisFrame = speed * Time.deltaTime;

        if (dir.magnitude <= distanceThisFrame)
        {
            HitTarget();
            return;
        }

        transform.Translate(dir.normalized * distanceThisFrame, Space.World);
    }

    void HitTarget()
    {
        // In a real game, you might have an explosion effect here.
        Destroy(target.gameObject);
        Destroy(gameObject);
    }
}
