using UnityEngine;

// This class controls the enemy's movement along a path.
public class EnemyController : MonoBehaviour
{
    public float speed = 2f;
    public static Transform[] waypoints;

    private int waypointIndex = 0;

    void Update()
    {
        if (waypointIndex >= waypoints.Length)
        {
            // Reached the end of the path
            Destroy(gameObject);
            return;
        }

        Transform targetWaypoint = waypoints[waypointIndex];
        transform.position = Vector2.MoveTowards(transform.position, targetWaypoint.position, speed * Time.deltaTime);

        if (Vector2.Distance(transform.position, targetWaypoint.position) < 0.1f)
        {
            waypointIndex++;
        }
    }
}