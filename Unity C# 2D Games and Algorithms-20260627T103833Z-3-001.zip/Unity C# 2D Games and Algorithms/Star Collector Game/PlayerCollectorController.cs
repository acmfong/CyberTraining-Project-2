using UnityEngine;
using UnityEngine.UI; // Required for UI elements like Text
using UnityEngine.SceneManagement; // Required for reloading the scene

// This class controls the player and manages the game's score.
public class PlayerCollectorController : MonoBehaviour
{
    [Tooltip("The speed at which the player moves horizontally.")]
    public float moveSpeed = 10f;

    private Rigidbody2D rb;
    private float moveInput;
    private int score = 0;
    private Text scoreText;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        // Find the ScoreText object in the scene to update it.
        scoreText = GameObject.Find("ScoreText").GetComponent<Text>();
        UpdateScoreText();
    }

    void Update()
    {
        // Get horizontal input (A/D keys or Left/Right arrow keys).
        moveInput = Input.GetAxis("Horizontal");
    }

    void FixedUpdate()
    {
        // Apply velocity to move the player horizontally.
        rb.velocity = new Vector2(moveInput * moveSpeed, 0);
    }

    // This function is called by Unity when this object's collider overlaps with another.
    void OnTriggerEnter2D(Collider2D other)
    {
        // Check if the object we collided with is tagged as a "Star".
        if (other.gameObject.CompareTag("Star"))
        {
            score += 10;
            UpdateScoreText();
            Destroy(other.gameObject); // Destroy the star after collecting it.
        }
        // Check if the object we collided with is tagged as a "Bomb".
        else if (other.gameObject.CompareTag("Bomb"))
        {
            // Reload the current scene to restart the game.
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    void UpdateScoreText()
    {
        scoreText.text = "Score: " + score;
    }
}
