using UnityEngine;
using UnityEngine.UI; // Required for UI elements

// This script automatically sets up the entire game scene when the game starts.
public class GameInitializerCollector : MonoBehaviour
{
    void Awake()
    {
        Camera.main.backgroundColor = Color.cyan;
        CreatePlayer();
        CreateBoundaries();
        CreateUI();
    }

    void Start()
    {
        // Start spawning items.
        InvokeRepeating("SpawnItem", 1f, 0.6f);
    }

    void CreatePlayer()
    {
        GameObject player = new GameObject("Player");
        player.transform.position = new Vector3(0, -4, 0);
        player.AddComponent<PlayerCollectorController>();

        SpriteRenderer playerSprite = player.AddComponent<SpriteRenderer>();
        playerSprite.color = Color.green;
        playerSprite.sortingOrder = 1;

        Rigidbody2D rb = player.AddComponent<Rigidbody2D>();
        rb.gravityScale = 0;

        // Make the collider a trigger so items pass through it but still register a collision.
        BoxCollider2D collider = player.AddComponent<BoxCollider2D>();
        collider.isTrigger = true;
    }

    void SpawnItem()
    {
        // Decide randomly whether to spawn a star or a bomb.
        if (Random.value < 0.75f) // 75% chance to spawn a star
        {
            CreateFallingObject("Star", Color.yellow);
        }
        else // 25% chance to spawn a bomb
        {
            CreateFallingObject("Bomb", Color.black);
        }
    }
    
    void CreateFallingObject(string tag, Color color)
    {
        GameObject item = new GameObject(tag);
        item.tag = tag;
        
        float randomX = Random.Range(-8f, 8f);
        item.transform.position = new Vector3(randomX, 6, 0);

        SpriteRenderer sprite = item.AddComponent<SpriteRenderer>();
        sprite.color = color;

        Rigidbody2D rb = item.AddComponent<Rigidbody2D>();
        rb.gravityScale = 0;

        item.AddComponent<BoxCollider2D>();
        item.AddComponent<FallingItem>();
    }

    void CreateBoundaries()
    {
        GameObject leftWall = new GameObject("LeftWall");
        leftWall.transform.position = new Vector3(-9, 0, 0);
        leftWall.AddComponent<BoxCollider2D>().size = new Vector2(1, 10);

        GameObject rightWall = new GameObject("RightWall");
        rightWall.transform.position = new Vector3(9, 0, 0);
        rightWall.AddComponent<BoxCollider2D>().size = new Vector2(1, 10);
    }

    void CreateUI()
    {
        // Create a Canvas for the UI
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>();
        canvasObj.AddComponent<GraphicRaycaster>();

        // Create the Text element for the score
        GameObject textObj = new GameObject("ScoreText");
        textObj.transform.SetParent(canvasObj.transform);

        Text scoreText = textObj.AddComponent<Text>();
        scoreText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        scoreText.fontSize = 24;
        scoreText.color = Color.black;
        scoreText.alignment = TextAnchor.UpperLeft;

        RectTransform rectTransform = scoreText.GetComponent<RectTransform>();
        rectTransform.anchorMin = new Vector2(0, 1);
        rectTransform.anchorMax = new Vector2(0, 1);
        rectTransform.pivot = new Vector2(0, 1);
        rectTransform.anchoredPosition = new Vector2(10, -10);
    }
}
