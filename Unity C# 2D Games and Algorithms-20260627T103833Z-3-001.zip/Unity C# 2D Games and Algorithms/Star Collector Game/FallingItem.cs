using UnityEngine;

// This class controls the behavior of the falling items (stars and bombs).
public class FallingItem : MonoBehaviour
{
    [Tooltip("The speed at which the item falls.")]
    public float fallSpeed = 4f;

    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        // Apply the falling velocity once at the start.
        rb.velocity = new Vector2(0, -fallSpeed);
    }

    void Update()
    {
        // If the item goes too far off the bottom of the screen, destroy it.
        if (transform.position.y < -6f)
        {
            Destroy(gameObject);
        }
    }
}