using UnityEngine;
using UnityEngine.SceneManagement; // Required for reloading the scene

// This class controls the player's movement and handles collision with hazards.
public class PlayerDodgerController : MonoBehaviour
{
    [Tooltip("The speed at which the player moves horizontally.")]
    public float moveSpeed = 8f;

    private Rigidbody2D rb;
    private float moveInput;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Get horizontal input (A/D keys or Left/Right arrow keys).
        moveInput = Input.GetAxis("Horizontal");
    }

    void FixedUpdate()
    {
        // Apply velocity to move the player horizontally.
        rb.velocity = new Vector2(moveInput * moveSpeed, 0);
    }

    // This function is called by Unity when this object collides with another.
    void OnCollisionEnter2D(Collision2D collision)
    {
        // Check if the object we collided with is tagged as a "Hazard".
        if (collision.gameObject.CompareTag("Hazard"))
        {
            // Reload the current scene to restart the game.
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}
