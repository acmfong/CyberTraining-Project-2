using UnityEngine;

// This class controls the behavior of the falling objects.
public class FallingObject : MonoBehaviour
{
    [Tooltip("The speed at which the object falls.")]
    public float fallSpeed = 5f;

    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        // Apply the falling velocity once at the start.
        rb.velocity = new Vector2(0, -fallSpeed);
    }

    // Update is called once per frame
    void Update()
    {
        // If the object goes too far off the bottom of the screen, destroy it to save memory.
        if (transform.position.y < -6f)
        {
            Destroy(gameObject);
        }
    }
}
