using UnityEngine;

// This script automatically sets up the entire game scene when the game starts.
public class GameInitializerDodger : MonoBehaviour
{
    // Awake is called when the script instance is being loaded.
    void Awake()
    {
        // Set the camera's background to black for better contrast.
        Camera.main.backgroundColor = Color.black;

        CreatePlayer();
        CreateBoundaries();
    }

    // Start is called after Awake. We use it to start the repeating spawn calls.
    void Start()
    {
        // Call the SpawnObject function every 0.7 seconds, starting after 1 second.
        InvokeRepeating("SpawnObject", 1f, 0.7f);
    }

    // Creates the player character.
    void CreatePlayer()
    {
        GameObject player = new GameObject("Player");
        player.transform.position = new Vector3(0, -4, 0);

        SpriteRenderer playerSprite = player.AddComponent<SpriteRenderer>();
        playerSprite.color = Color.blue;
        playerSprite.sortingOrder = 1; // Make sure player is drawn on top of other things

        Rigidbody2D rb = player.AddComponent<Rigidbody2D>();
        rb.gravityScale = 0; // The player should not be affected by gravity

        player.AddComponent<BoxCollider2D>();
        player.AddComponent<PlayerDodgerController>();
    }

    // Spawns a new falling object at a random position.
    void SpawnObject()
    {
        GameObject fallingObject = new GameObject("FallingObject");
        
        // Set a random horizontal position at the top of the screen.
        float randomX = Random.Range(-8f, 8f);
        fallingObject.transform.position = new Vector3(randomX, 6, 0);

        SpriteRenderer sprite = fallingObject.AddComponent<SpriteRenderer>();
        sprite.color = Color.red;

        Rigidbody2D rb = fallingObject.AddComponent<Rigidbody2D>();
        rb.gravityScale = 0; // We will control velocity manually

        fallingObject.AddComponent<BoxCollider2D>();
        fallingObject.AddComponent<FallingObject>();

        // This tag is crucial for the collision detection to work.
        fallingObject.tag = "Hazard";
    }

    // Creates invisible walls to keep the player on the screen.
    void CreateBoundaries()
    {
        // Left Wall
        GameObject leftWall = new GameObject("LeftWall");
        leftWall.transform.position = new Vector3(-9, 0, 0);
        BoxCollider2D leftCollider = leftWall.AddComponent<BoxCollider2D>();
        leftCollider.size = new Vector2(1, 10);

        // Right Wall
        GameObject rightWall = new GameObject("RightWall");
        rightWall.transform.position = new Vector3(9, 0, 0);
        BoxCollider2D rightCollider = rightWall.AddComponent<BoxCollider2D>();
        rightCollider.size = new Vector2(1, 10);
    }
}
