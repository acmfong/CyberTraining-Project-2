using UnityEngine;
using UnityEngine.SceneManagement;

// This class controls the player's movement within the maze.
public class PlayerMazeController : MonoBehaviour
{
    [Tooltip("The speed at which the player moves.")]
    public float moveSpeed = 5f;

    private Rigidbody2D rb;
    private Vector2 moveInput;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Get both horizontal and vertical input.
        moveInput.x = Input.GetAxisRaw("Horizontal");
        moveInput.y = Input.GetAxisRaw("Vertical");
    }

    void FixedUpdate()
    {
        // Apply velocity to move the player.
        rb.velocity = moveInput.normalized * moveSpeed;
    }

    // This function is called when the player collides with another object.
    void OnCollisionEnter2D(Collision2D collision)
    {
        // Check if the object we collided with is the "Goal".
        if (collision.gameObject.CompareTag("Goal"))
        {
            // Reload the scene to generate a new maze and restart.
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}