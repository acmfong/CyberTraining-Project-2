using UnityEngine;

// This script automatically sets up the entire maze game scene.
public class GameInitializerMaze : MonoBehaviour
{
    [Header("Maze Settings")]
    public int mazeWidth = 15;
    public int mazeHeight = 10;
    public float cellSize = 1f;

    void Awake()
    {
        Camera.main.backgroundColor = new Color(0.1f, 0.1f, 0.1f);
        Camera.main.orthographicSize = Mathf.Max(mazeWidth, mazeHeight);

        MazeGenerator generator = new MazeGenerator();
        MazeCell[,] maze = generator.Generate(mazeWidth, mazeHeight);

        DrawMaze(maze);
        SpawnPlayer();
        SpawnGoal();
    }

    void DrawMaze(MazeCell[,] maze)
    {
        GameObject mazeContainer = new GameObject("MazeContainer");
        Vector3 offset = new Vector3(-mazeWidth * cellSize / 2f, -mazeHeight * cellSize / 2f, 0);

        for (int x = 0; x < mazeWidth; x++)
        {
            for (int y = 0; y < mazeHeight; y++)
            {
                Vector3 position = new Vector3(x * cellSize, y * cellSize, 0) + offset;

                if (maze[x, y].wallLeft)
                {
                    GameObject wall = CreateWallSegment();
                    wall.transform.position = position + new Vector3(-cellSize / 2, 0, 0);
                    wall.transform.localScale = new Vector3(0.1f, cellSize, 1f);
                    wall.transform.SetParent(mazeContainer.transform);
                }
                if (maze[x, y].wallBottom)
                {
                    GameObject wall = CreateWallSegment();
                    wall.transform.position = position + new Vector3(0, -cellSize / 2, 0);
                    wall.transform.localScale = new Vector3(cellSize, 0.1f, 1f);
                    wall.transform.SetParent(mazeContainer.transform);
                }
            }
        }
        
        // Create outer boundary walls
        GameObject topWall = CreateWallSegment();
        topWall.transform.position = new Vector3(0, mazeHeight * cellSize, 0) + offset;
        topWall.transform.localScale = new Vector3(mazeWidth * cellSize, 0.1f, 1f);
        topWall.transform.SetParent(mazeContainer.transform);

        GameObject rightWall = CreateWallSegment();
        rightWall.transform.position = new Vector3(mazeWidth * cellSize, 0, 0) + offset;
        rightWall.transform.localScale = new Vector3(0.1f, mazeHeight * cellSize, 1f);
        rightWall.transform.SetParent(mazeContainer.transform);
    }

    GameObject CreateWallSegment()
    {
        GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
        wall.GetComponent<Renderer>().material.color = Color.white;
        return wall;
    }

    void SpawnPlayer()
    {
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Cube);
        player.name = "Player";
        player.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
        player.GetComponent<Renderer>().material.color = Color.blue;

        Vector3 startPosition = new Vector3((-mazeWidth / 2f + 0.5f) * cellSize, (mazeHeight / 2f - 0.5f) * cellSize, 0);
        player.transform.position = startPosition;

        player.AddComponent<Rigidbody2D>().gravityScale = 0;
        player.AddComponent<PlayerMazeController>();
    }

    void SpawnGoal()
    {
        GameObject goal = GameObject.CreatePrimitive(PrimitiveType.Cube);
        goal.name = "Goal";
        goal.tag = "Goal";
        goal.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
        goal.GetComponent<Renderer>().material.color = Color.yellow;

        Vector3 endPosition = new Vector3((mazeWidth / 2f - 0.5f) * cellSize, (-mazeHeight / 2f + 0.5f) * cellSize, 0);
        goal.transform.position = endPosition;
    }
}
