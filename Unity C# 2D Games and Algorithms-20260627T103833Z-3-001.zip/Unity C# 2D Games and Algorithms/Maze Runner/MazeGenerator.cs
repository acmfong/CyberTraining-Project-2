using UnityEngine;
using System.Collections.Generic;

// This class defines the structure for each cell in our maze grid.
public class MazeCell
{
    public bool visited = false;
    public bool wallLeft = true;
    public bool wallBottom = true;
}

// This class uses a Recursive Backtracking algorithm to generate a maze.
public class MazeGenerator
{
    public int width;
    public int height;

    public MazeCell[,] Generate(int mazeWidth, int mazeHeight)
    {
        width = mazeWidth;
        height = mazeHeight;
        MazeCell[,] maze = new MazeCell[width, height];

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                maze[x, y] = new MazeCell();
            }
        }

        // Start the recursive generation from a random cell.
        CarveMaze(maze, 0, 0);

        return maze;
    }

    private void CarveMaze(MazeCell[,] maze, int x, int y)
    {
        maze[x, y].visited = true;
        List<int> directions = new List<int> { 0, 1, 2, 3 }; // 0:Up, 1:Right, 2:Down, 3:Left
        Shuffle(directions);

        foreach (int dir in directions)
        {
            int nextX = x;
            int nextY = y;

            switch (dir)
            {
                case 0: nextY++; break; // Up
                case 1: nextX++; break; // Right
                case 2: nextY--; break; // Down
                case 3: nextX--; break; // Left
            }

            // Check if the next cell is within bounds and not visited.
            if (nextX >= 0 && nextX < width && nextY >= 0 && nextY < height && !maze[nextX, nextY].visited)
            {
                // Carve a path.
                if (dir == 0) maze[x, y].wallBottom = false;      // Carve wall above current cell (which is bottom of next cell)
                else if (dir == 1) maze[x, y + 1].wallLeft = false; // Carve wall to the right of current cell
                else if (dir == 2) maze[x, y - 1].wallBottom = false; // Carve wall below current cell
                else if (dir == 3) maze[x - 1, y + 1].wallLeft = false; // Carve wall to the left of current cell

                CarveMaze(maze, nextX, nextY);
            }
        }
    }
    
    // Simple Fisher-Yates shuffle to randomize directions.
    private void Shuffle<T>(List<T> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            int randomIndex = Random.Range(i, list.Count);
            T temp = list[i];
            list[i] = list[randomIndex];
            list[randomIndex] = temp;
        }
    }
}
