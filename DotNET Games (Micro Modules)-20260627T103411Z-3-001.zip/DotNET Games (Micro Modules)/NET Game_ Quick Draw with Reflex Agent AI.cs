using System;
using System.Diagnostics;
using System.Threading;

/// <summary>
/// Main class for the Quick Draw game.
/// This program demonstrates an event-driven loop and a simple reflex agent AI.
/// The core gameplay is about reacting to a visual cue ("DRAW!") as quickly as possible.
/// The AI opponent simulates a reflex agent with a fixed (but random) reaction time.
/// </summary>
public class QuickDrawGame
{
    private static int playerScore = 0;
    private static int aiScore = 0;
    private static Random random = new Random();

    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Reflex Agent Quick Draw";
        Console.ForegroundColor = ConsoleColor.White;

        PrintGameIntro();

        // Main game loop
        while (true)
        {
            Console.WriteLine("--------------------------------------------------");
            RunRound();
            PrintScore();

            Console.Write("\nReady for another round? (y/n): ");
            if (Console.ReadLine().ToLower() != "y")
            {
                break;
            }
        }

        Console.WriteLine("\nThanks for playing!");
    }

    /// <summary>
    /// Prints the introductory text and instructions for the game.
    /// </summary>
    private static void PrintGameIntro()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
     ___       _ _   _      ___  __      __   
    |__  |  | | | \ | |    |__  |__)    /  `  
    |___ |/\| | |_/ |_|    |___ |  \    \__, .
                                             
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Quick Draw!");
        Console.WriteLine("This game simulates a 'Reflex Agent' AI.");
        Console.WriteLine("When you see the 'DRAW!' signal, press any key as fast as you can.");
        Console.WriteLine("The AI doesn't think; it just reacts to the event, like a simple robot.");
        Console.WriteLine("This is an event-driven loop: Wait for stimulus -> React.\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Runs a single round of the Quick Draw game.
    /// </summary>
    private static void RunRound()
    {
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine("Get ready... Wait for the signal.");
        
        // Wait for a random amount of time before showing the signal
        Thread.Sleep(random.Next(2000, 5000));

        // --- THE EVENT HAPPENS HERE ---
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("\n>>>> DRAW! <<<<");
        Console.ResetColor();

        Stopwatch stopwatch = Stopwatch.StartNew();

        // The loop that waits for the player's reaction.
        // This is the core of the event-driven model for the player.
        while (!Console.KeyAvailable)
        {
            // Do nothing, just wait for the key press event.
            // A more complex agent might check for other stimuli here.
        }
        stopwatch.Stop();
        
        // Clear the key from the input buffer
        Console.ReadKey(true); 

        long playerReactionTime = stopwatch.ElapsedMilliseconds;

        // --- AI REFLEX AGENT SIMULATION ---
        // The AI's reaction is not measured, but simulated as a simple reflex.
        // It has a base reaction time with some randomness.
        int aiReactionTime = random.Next(150, 400); // AI reacts between 0.15s and 0.4s

        Console.WriteLine($"\nYour reaction time: {playerReactionTime} ms");
        Console.WriteLine($"AI reflex time:     {aiReactionTime} ms");

        if (playerReactionTime < aiReactionTime)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nYou were faster! You win the round!");
            playerScore++;
        }
        else if (playerReactionTime > aiReactionTime)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nThe AI was faster! You lose.");
            aiScore++;
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nIt's a perfect tie!");
        }
        Console.ResetColor();
    }

    /// <summary>
    /// Prints the current score to the console.
    /// </summary>
    private static void PrintScore()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"\nSCORE: Player - {playerScore} | AI - {aiScore}");
        Console.ResetColor();
    }
}
