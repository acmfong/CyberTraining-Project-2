using System;
using System.Linq;
using System.Threading;

/// <summary>
/// Main class for the Tic Tac Toe game.
/// This program demonstrates the Minimax algorithm, a foundational concept in
/// game theory and adversarial search. The AI opponent plays perfectly by
/// recursively evaluating all possible future moves to find the optimal one.
/// </summary>
public class TicTacToeGame
{
    private static char[] board = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    private const char playerMarker = 'X';
    private const char aiMarker = 'O';

    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Minimax Tic Tac Toe";
        PrintGameIntro();

        // Main game loop
        while (true)
        {
            DrawBoard();
            
            // Player's turn
            PlayerMove();
            if (CheckForWinner(playerMarker))
            {
                DrawBoard();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\nCongratulations! You won!");
                break;
            }
            if (IsBoardFull())
            {
                DrawBoard();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nIt's a draw!");
                break;
            }

            // AI's turn
            AIMove();
            if (CheckForWinner(aiMarker))
            {
                DrawBoard();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nThe AI has won!");
                break;
            }
            if (IsBoardFull())
            {
                DrawBoard();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nIt's a draw!");
                break;
            }
        }
        Console.ResetColor();
        Console.WriteLine("\nThanks for playing!");
    }

    /// <summary>
    /// Prints the introductory text and instructions.
    /// </summary>
    private static void PrintGameIntro()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
     _____ _   _    _____    _____   ___   ___  
    |_   _(_) | |  |_   _|  |_   _| / _ \ / _ \ 
      | |  _  | |    | |      | |  / / \ \/ / \ \
      | | | | | |    | |      | | | |   | || |   | |
      | | | | | |____| |      | | | \_/ / \_/ /
      \_/ |_| \_____/\_/      \_/  \___/ \___/ 
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Tic Tac Toe!");
        Console.WriteLine("You are playing against an AI that uses the 'Minimax' algorithm.");
        Console.WriteLine("This is a form of 'adversarial search' where the AI looks at all possible future moves.");
        Console.WriteLine("It assumes you will always play perfectly, and it chooses the move that guarantees it will not lose.");
        Console.WriteLine("It is impossible to beat this AI. The best you can achieve is a draw.\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Handles the AI's turn by finding the best possible move using Minimax.
    /// </summary>
    private static void AIMove()
    {
        Console.WriteLine("\nAI is thinking...");
        Thread.Sleep(700);
        int bestMove = FindBestMove();
        board[bestMove] = aiMarker;
        Console.WriteLine($"AI places its '{aiMarker}' on position {bestMove + 1}.");
    }

    /// <summary>
    /// Handles the player's turn and validates their input.
    /// </summary>
    private static void PlayerMove()
    {
        while (true)
        {
            Console.Write($"\nYour turn. Choose a position (1-9) to place your '{playerMarker}': ");
            if (int.TryParse(Console.ReadLine(), out int choice) && choice >= 1 && choice <= 9)
            {
                if (board[choice - 1] != playerMarker && board[choice - 1] != aiMarker)
                {
                    board[choice - 1] = playerMarker;
                    break;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("That position is already taken!");
                    Console.ResetColor();
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid input. Please enter a number from 1 to 9.");
                Console.ResetColor();
            }
        }
    }
    
    /// <summary>
    /// Finds the best move for the AI by evaluating all empty spots with the Minimax algorithm.
    /// </summary>
    private static int FindBestMove()
    {
        int bestScore = int.MinValue;
        int bestMove = -1;

        for (int i = 0; i < 9; i++)
        {
            // Check if the spot is available
            if (board[i] != playerMarker && board[i] != aiMarker)
            {
                char original = board[i];
                board[i] = aiMarker; // Make the move
                int moveScore = Minimax(false); // Call minimax on the new board state for the minimizing player
                board[i] = original; // Undo the move

                if (moveScore > bestScore)
                {
                    bestScore = moveScore;
                    bestMove = i;
                }
            }
        }
        return bestMove;
    }

    /// <summary>
    /// The core Minimax algorithm. It recursively evaluates board states.
    /// </summary>
    /// <param name="isMaximizing">True if it's the AI's turn (wants to maximize score), false for player's turn (wants to minimize score).</param>
    /// <returns>The score of the board state (+10 for AI win, -10 for Player win, 0 for draw).</returns>
    private static int Minimax(bool isMaximizing)
    {
        // Check for terminal states (win/loss/draw)
        if (CheckForWinner(aiMarker)) return 10;
        if (CheckForWinner(playerMarker)) return -10;
        if (IsBoardFull()) return 0;

        if (isMaximizing) // AI's turn (Maximizer)
        {
            int bestScore = int.MinValue;
            for (int i = 0; i < 9; i++)
            {
                if (board[i] != playerMarker && board[i] != aiMarker)
                {
                    char original = board[i];
                    board[i] = aiMarker;
                    bestScore = Math.Max(bestScore, Minimax(false));
                    board[i] = original;
                }
            }
            return bestScore;
        }
        else // Player's turn (Minimizer)
        {
            int bestScore = int.MaxValue;
            for (int i = 0; i < 9; i++)
            {
                if (board[i] != playerMarker && board[i] != aiMarker)
                {
                    char original = board[i];
                    board[i] = playerMarker;
                    bestScore = Math.Min(bestScore, Minimax(true));
                    board[i] = original;
                }
            }
            return bestScore;
        }
    }
    
    /// <summary>
    /// Checks if a given player has won the game.
    /// </summary>
    private static bool CheckForWinner(char marker)
    {
        // Check rows, columns, and diagonals
        return ((board[0] == marker && board[1] == marker && board[2] == marker) ||
                (board[3] == marker && board[4] == marker && board[5] == marker) ||
                (board[6] == marker && board[7] == marker && board[8] == marker) ||
                (board[0] == marker && board[3] == marker && board[6] == marker) ||
                (board[1] == marker && board[4] == marker && board[7] == marker) ||
                (board[2] == marker && board[5] == marker && board[8] == marker) ||
                (board[0] == marker && board[4] == marker && board[8] == marker) ||
                (board[2] == marker && board[4] == marker && board[6] == marker));
    }

    /// <summary>
    /// Checks if the board is full (resulting in a draw).
    /// </summary>
    private static bool IsBoardFull()
    {
        return !board.Any(c => c != playerMarker && c != aiMarker);
    }

    /// <summary>
    /// Draws the current Tic Tac Toe board to the console.
    /// </summary>
    private static void DrawBoard()
    {
        Console.Clear();
        PrintGameIntro();
        Console.WriteLine("     |     |      ");
        Console.WriteLine($"  {GetMarkerColor(board[0])}  |  {GetMarkerColor(board[1])}  |  {GetMarkerColor(board[2])}");
        Console.WriteLine("_____|_____|_____ ");
        Console.WriteLine("     |     |      ");
        Console.WriteLine($"  {GetMarkerColor(board[3])}  |  {GetMarkerColor(board[4])}  |  {GetMarkerColor(board[5])}");
        Console.WriteLine("_____|_____|_____ ");
        Console.WriteLine("     |     |      ");
        Console.WriteLine($"  {GetMarkerColor(board[6])}  |  {GetMarkerColor(board[7])}  |  {GetMarkerColor(board[8])}");
        Console.WriteLine("     |     |      ");
    }

    /// <summary>
    /// Helper to return a colored marker string for the board display.
    /// </summary>
    private static string GetMarkerColor(char marker)
    {
        if (marker == playerMarker)
        {
            return $"\u001b[32m{marker}\u001b[0m"; // Green X
        }
        if (marker == aiMarker)
        {
            return $"\u001b[31m{marker}\u001b[0m"; // Red O
        }
        return marker.ToString();
    }
}
