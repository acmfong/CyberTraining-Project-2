using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

/// <summary>
/// Represents a single musical note with a corresponding keyboard key.
/// </summary>
public struct Note
{
    public char Key { get; }
    public int Frequency { get; } // in Hertz

    public Note(char key, int frequency)
    {
        Key = key;
        Frequency = frequency;
    }
}

/// <summary>
/// Main class for the Beep Pad game.
/// Simulates a signal response agent using sensor-driven interaction (sound/vision)
/// and a simple reinforcement learning loop for feedback.
/// </summary>
public class BeepPadGame
{
    private readonly List<Note> _sequence;
    private readonly Random _random;
    private readonly Dictionary<char, Note> _noteMap;
    private int _score;

    public BeepPadGame()
    {
        _sequence = new List<Note>();
        _random = new Random();
        _score = 0;

        // Define the "Beep Pad" - mapping keys to musical notes (frequencies)
        _noteMap = new Dictionary<char, Note>
        {
            { 'A', new Note('A', 261) }, // C4
            { 'S', new Note('S', 294) }, // D4
            { 'D', new Note('D', 329) }, // E4
            { 'F', new Note('F', 349) }, // F4
            { 'J', new Note('J', 392) }, // G4
            { 'K', new Note('K', 440) }, // A4
            { 'L', new Note('L', 493) }, // B4
            { ';', new Note(';', 523) }  // C5
        };
    }

    /// <summary>
    /// Starts and runs the main game loop.
    /// </summary>
    public void Run()
    {
        PrintGameIntro();

        while (true)
        {
            AddNewNoteToSequence();
            DisplaySequence();

            if (!GetPlayerInputAndVerify())
            {
                // Game over on wrong input
                break;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\nCorrect! Next round...");
            Thread.Sleep(1500);
        }

        PrintFinalMessage();
    }

    /// <summary>
    /// Plays a note both audibly and visually.
    /// </summary>
    private void PlayNote(Note note, int duration = 300)
    {
        Console.Write("Pressing key: ");
        Console.BackgroundColor = ConsoleColor.DarkCyan;
        Console.ForegroundColor = ConsoleColor.White;
        Console.Write($" {note.Key} ");
        Console.ResetColor();
        
        // This is a Windows-only feature
        Console.Beep(note.Frequency, duration);
        
        Console.SetCursorPosition(0, Console.CursorTop);
        Console.Write(new string(' ', Console.WindowWidth)); 
        Console.SetCursorPosition(0, Console.CursorTop);
    }

    /// <summary>
    /// Displays the current sequence for the player to memorize.
    /// </summary>
    private void DisplaySequence()
    {
        Console.Clear();
        Console.WriteLine($"Score: {_score}");
        Console.WriteLine($"Memorize the sequence (Round {_sequence.Count})...");
        Thread.Sleep(1200);

        foreach (var note in _sequence)
        {
            PlayNote(note);
            Thread.Sleep(150); // Pause between notes
        }
    }

    /// <summary>
    /// Gathers player input and verifies it against the sequence in real-time.
    /// </summary>
    /// <returns>True if the player correctly entered the full sequence, otherwise false.</returns>
    private bool GetPlayerInputAndVerify()
    {
        Console.Clear();
        Console.WriteLine($"Score: {_score}");
        Console.WriteLine("Your turn! Play the sequence back.");
        Console.WriteLine("Use keys: A S D F J K L ;");

        for (int i = 0; i < _sequence.Count; i++)
        {
            char inputChar = char.ToUpper(Console.ReadKey(true).KeyChar);
            Note expectedNote = _sequence[i];

            if (_noteMap.TryGetValue(inputChar, out Note playedNote) && playedNote.Key == expectedNote.Key)
            {
                // --- POSITIVE REINFORCEMENT ---
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write($"Correct! ({playedNote.Key}) ");
                Console.Beep(playedNote.Frequency, 150); // Reward beep
                Console.ResetColor();
                _score++;
            }
            else
            {
                // --- NEGATIVE REINFORCEMENT ---
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n\nWrong key! Expected '{expectedNote.Key}' but you pressed '{inputChar}'.");
                Console.Beep(150, 500); // Punishment beep
                return false;
            }
        }
        return true;
    }

    private void AddNewNoteToSequence()
    {
        int index = _random.Next(_noteMap.Count);
        _sequence.Add(_noteMap.Values.ElementAt(index));
    }

    private void PrintGameIntro()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
 ____  _____ _____ ____    ____    _    ____  
| __ )| ____| ____|  _ \  |  _ \  / \  |  _ \ 
|  _ \|  _| |  _| | |_) | | |_) |/ _ \ | | | |
| |_) | |___| |___|  __/  |  __/ ___ \| |_| |
|____/|_____|_____|_|     |_| /_/   \_\____/ 
                                             
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Beep Pad! (Windows Only)");
        Console.WriteLine("This game simulates a 'Signal Response Agent'.");
        Console.WriteLine("You must respond to the audio-visual signals (beeps).");
        Console.WriteLine("Correct responses are rewarded, incorrect ones are punished (Simple Reinforcement Learning).\n");
        Console.ResetColor();
        Console.WriteLine("Press any key to start...");
        Console.ReadKey(true);
    }

    private void PrintFinalMessage()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\n\n================ GAME OVER ================");
        Console.WriteLine($"Your final score is: {_score}");
        Console.ResetColor();
        Console.WriteLine("\nThanks for playing!");
    }
}

/// <summary>
/// The main entry point for the program.
/// </summary>
public class Program
{
    public static void Main(string[] args)
    {
        if (OperatingSystem.IsWindows())
        {
            Console.Title = "AI Learning Game: Signal Response Agent";
            Console.CursorVisible = false;
            var game = new BeepPadGame();
            game.Run();
            Console.CursorVisible = true;
        }
        else
        {
            Console.WriteLine("This application requires the Windows operating system to use Console.Beep().");
        }
    }
}
