using System;
using System.Diagnostics;
using System.Threading;

/// <summary>
/// Main class for the Whack A Mole game.
/// This program simulates a reactive agent that uses spatial tracking and
/// action selection. The player must quickly react to a mole appearing
/// at a random position on a grid, demonstrating a simple perception-action loop.
/// </summary>
public class WhackAMoleGame
{
    private static int score = 0;
    private static int roundsPlayed = 0;
    private const int totalRounds = 10;
    private const int boardSize = 9; // 3x3 grid
    private const int reactionTimeLimitMs = 2000; // 2 seconds to react
    private static Random random = new Random();

    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Reactive Agent Whack A Mole";
        Console.CursorVisible = false;

        PrintGameIntro();
        Console.WriteLine("Press any key to start...");
        Console.ReadKey(true);

        // Main game loop for a set number of rounds
        for (roundsPlayed = 1; roundsPlayed <= totalRounds; roundsPlayed++)
        {
            RunRound();
        }

        PrintFinalScore();
        Console.CursorVisible = true;
    }

    /// <summary>
    /// Prints the introductory text and instructions.
    /// </summary>
    private static void PrintGameIntro()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
 __      __   __   __          __   ___  _    _      ___  __  
|  \ |  /  ` /  ` /  \ \    / /  ` |__  | \  / |    |__  |__) 
|__/ |__\__, \__, \__/  \/\/  \__, |___ |  \/  |    |___ |  \ 
                                                              
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Whack A Mole!");
        Console.WriteLine("This game simulates a 'Reactive Agent'. You are the agent!");
        Console.WriteLine("Your task is to perform 'Action Selection' based on 'Spatial Tracking'.");
        Console.WriteLine("\n1. A mole 'O' will appear in one of the 9 holes.");
        Console.WriteLine("2. You must press the corresponding number key (1-9) to whack it.");
        Console.WriteLine($"3. You only have {reactionTimeLimitMs / 1000} seconds to react!\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Runs a single round of the game.
    /// </summary>
    private static void RunRound()
    {
        Console.Clear();
        PrintScore();

        // --- PERCEPTION STEP ---
        // The agent perceives the environment to find the mole.
        int molePosition = random.Next(1, boardSize + 1);
        
        DrawBoard(molePosition);
        Console.WriteLine("\nA mole appears! Whack it!");

        Stopwatch stopwatch = Stopwatch.StartNew();
        char? playerInput = null;

        // This loop waits for the player's action, but only for a limited time.
        while (stopwatch.ElapsedMilliseconds < reactionTimeLimitMs)
        {
            if (Console.KeyAvailable)
            {
                playerInput = Console.ReadKey(true).KeyChar;
                break; // Action was selected
            }
            Thread.Sleep(10); // Small delay to prevent busy-waiting
        }
        stopwatch.Stop();

        // --- ACTION AND RESULT ---
        Console.Clear();
        PrintScore();
        DrawBoard(-1); // Draw an empty board to show the result

        if (!playerInput.HasValue)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"\nToo slow! The mole got away. (Your time: >{reactionTimeLimitMs}ms)");
        }
        else if (int.TryParse(playerInput.ToString(), out int whackPosition) && whackPosition == molePosition)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nWHACK! You got it! (Your time: {stopwatch.ElapsedMilliseconds}ms)");
            score++;
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"\nMISS! You whacked hole {playerInput} but the mole was at {molePosition}.");
        }
        
        Console.ResetColor();
        Thread.Sleep(1500); // Pause to show the result
    }

    /// <summary>
    /// Draws the game board with the mole at a given position.
    /// </summary>
    /// <param name="molePosition">The position (1-9) of the mole. -1 for no mole.</param>
    private static void DrawBoard(int molePosition)
    {
        Console.WriteLine();
        for (int i = 1; i <= boardSize; i++)
        {
            Console.Write("[");
            if (i == molePosition)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("O"); // The Mole
                Console.ResetColor();
            }
            else
            {
                Console.Write(i); // The hole number
            }
            Console.Write("]");

            if (i % 3 == 0)
            {
                Console.WriteLine(); // New row
            }
            else
            {
                Console.Write(" ");
            }
        }
    }

    /// <summary>
    /// Prints the current score and round number.
    /// </summary>
    private static void PrintScore()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"Round: {roundsPlayed}/{totalRounds} | Score: {score}");
        Console.WriteLine("--------------------------");
        Console.ResetColor();
    }
    
    /// <summary>
    /// Prints the final score at the end of the game.
    /// </summary>
    private static void PrintFinalScore()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("==========================");
        Console.WriteLine("      GAME OVER");
        Console.WriteLine("==========================");
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"\nYour final score is: {score} out of {totalRounds}");
        Console.ResetColor();
        Console.WriteLine("\nThanks for playing!");
    }
}
