using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

/// <summary>
/// Main class for the Tower of Hanoi game.
/// This program uses a recursive algorithm (a form of Depth-First Search)
/// to solve the puzzle, demonstrating symbolic reasoning and state transitions.
/// </summary>
public class TowerOfHanoiGame
{
    private readonly int _numDisks;
    private readonly Stack<int>[] _towers;
    private int _moveCount = 0;

    public TowerOfHanoiGame(int numDisks)
    {
        if (numDisks < 2 || numDisks > 8)
        {
            throw new ArgumentOutOfRangeException(nameof(numDisks), "Number of disks must be between 2 and 8 for a good visualization.");
        }
        _numDisks = numDisks;
        _towers = new Stack<int>[3];
        for (int i = 0; i < 3; i++)
        {
            _towers[i] = new Stack<int>();
        }
        // Place all disks on the first tower
        for (int i = _numDisks; i > 0; i--)
        {
            _towers[0].Push(i);
        }
    }

    /// <summary>
    /// Starts the game and the recursive solving process.
    /// </summary>
    public void Run()
    {
        PrintGameIntro();
        DrawTowers();
        Console.WriteLine("\nPress any key to begin the automated solution...");
        Console.ReadKey(true);
        
        // Start the recursive solving algorithm
        Solve(_numDisks, 0, 2, 1);
    }

    /// <summary>
    /// The core recursive function that solves the puzzle.
    /// This is a classic example of Depth-First Search.
    /// </summary>
    /// <param name="disksToMove">The number of disks we are currently trying to move.</param>
    /// <param name="sourcePeg">The starting peg.</param>
    /// <param name="destPeg">The destination peg.</param>
    /// <param name="auxPeg">The auxiliary (temporary) peg.</param>
    private void Solve(int disksToMove, int sourcePeg, int destPeg, int auxPeg)
    {
        // Base case: If there are no disks to move, we're done with this sub-problem.
        if (disksToMove == 0)
        {
            return;
        }

        // --- RECURSIVE STEP 1 ---
        // Move n-1 disks from the source peg to the auxiliary peg,
        // using the destination peg as temporary storage.
        Solve(disksToMove - 1, sourcePeg, auxPeg, destPeg);

        // --- THE MOVE (STATE TRANSITION) ---
        // Move the one remaining (largest) disk from the source to the destination peg.
        int disk = _towers[sourcePeg].Pop();
        _towers[destPeg].Push(disk);
        _moveCount++;
        
        // Animate the move
        Console.Clear();
        PrintGameIntro();
        DrawTowers();
        Console.WriteLine($"\nMove #{_moveCount}: Moved disk {disk} from Tower {sourcePeg + 1} to Tower {destPeg + 1}");
        Thread.Sleep(500);

        // --- RECURSIVE STEP 2 ---
        // Move the n-1 disks from the auxiliary peg to the destination peg,
        // using the original source peg as temporary storage.
        Solve(disksToMove - 1, auxPeg, destPeg, sourcePeg);
    }

    /// <summary>
    /// Draws the current state of the three towers.
    /// </summary>
    private void DrawTowers()
    {
        Console.WriteLine();
        int maxHeight = _numDisks + 1;
        var towerArrays = _towers.Select(t => t.ToArray()).ToArray();

        for (int height = maxHeight; height >= 1; height--)
        {
            Console.Write("  ");
            for (int tower = 0; tower < 3; tower++)
            {
                int diskIndex = Array.IndexOf(towerArrays[tower], height);
                if (diskIndex != -1)
                {
                    // This level has a disk, but we need to find its size
                    int diskSize = towerArrays[tower][towerArrays[tower].Length - height];
                    string diskStr = new string('=', diskSize);
                    string padding = new string(' ', _numDisks - diskSize);
                    Console.Write(padding + diskStr + "|" + diskStr + padding);
                }
                else
                {
                    // Empty space at this level
                    string padding = new string(' ', _numDisks);
                    Console.Write(padding + "|" + padding);
                }
                Console.Write("  ");
            }
            Console.WriteLine();
        }
        // Draw base
        Console.WriteLine(new string('-', (_numDisks * 2 + 3) * 3));
        Console.WriteLine($"    Tower 1{new string(' ', _numDisks * 2 - 4)}Tower 2{new string(' ', _numDisks * 2 - 4)}Tower 3");
    }

    private void PrintGameIntro()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
 _____   ___   __      __ _____   ___   _   _    _    _   _ 
|_   _| / _ \  \ \    / /|_   _| / _ \ | \ | |  / \  | \ | |
  | |  | | | |  \ \  / /   | |  | | | ||  \| | / _ \ |  \| |
  | |  | |_| |   \ \/ /    | |  | |_| || |\  |/ ___ \| |\  |
  |_|   \___/     \__/     |_|   \___/ |_| \_/_/   \_\_| \_|
                                                          
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to the Tower of Hanoi!");
        Console.WriteLine("This puzzle is solved by an AI using 'Recursion' and 'Symbolic Reasoning'.");
        Console.WriteLine("The AI uses a Depth-First Search strategy to find the optimal sequence of moves.\n");
        Console.ResetColor();
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Recursive Tower of Hanoi";
        Console.CursorVisible = false;
        
        int numDisks = 4; // You can change this value (2-8)
        var game = new TowerOfHanoiGame(numDisks);
        game.Run();
        
        Console.WriteLine("\n\nPuzzle Solved! Thanks for watching.");
        Console.CursorVisible = true;
    }
}
