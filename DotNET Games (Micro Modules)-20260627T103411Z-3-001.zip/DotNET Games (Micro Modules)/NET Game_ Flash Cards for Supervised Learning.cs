using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

/// <summary>
/// Represents a single flash card with a question and its correct answer.
/// In supervised learning, this is analogous to a single data point with its label.
/// </summary>
public class FlashCard
{
    public string Question { get; }
    public string Answer { get; }

    public FlashCard(string question, string answer)
    {
        Question = question;
        Answer = answer;
    }
}

/// <summary>
/// Main class for the Flash Cards game.
/// This program simulates supervised learning through a Q&A format.
/// The player is presented with questions (data) and their answers are checked
/// against the correct answers (labels) to reinforce learning.
/// </summary>
public class FlashCardsGame
{
    private static int correctAnswers = 0;
    private static Random random = new Random();

    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Supervised Learning Flash Cards";
        Console.ForegroundColor = ConsoleColor.White;

        PrintGameIntro();

        // This list of flash cards is our "labeled dataset" for the training session.
        List<FlashCard> deck = CreateAIDeck();
        
        // Randomize the order of the cards for each session.
        List<FlashCard> shuffledDeck = deck.OrderBy(c => random.Next()).ToList();

        // --- "TRAINING" LOOP ---
        // Iterate through each data point (flash card) in our dataset.
        for (int i = 0; i < shuffledDeck.Count; i++)
        {
            FlashCard card = shuffledDeck[i];
            
            Console.WriteLine("--------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"Card {i + 1} of {shuffledDeck.Count}");
            Console.WriteLine($"\nQuestion: {card.Question}");
            
            Console.Write("\nYour Answer: ");
            string userAnswer = Console.ReadLine();

            // This is the "supervision" step. We compare the prediction (user's answer)
            // with the ground truth (the card's actual answer).
            if (userAnswer.Trim().Equals(card.Answer, StringComparison.OrdinalIgnoreCase))
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\nCorrect! You are learning.");
                correctAnswers++;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\nIncorrect. The correct answer is: {card.Answer}");
            }
            Console.ResetColor();
            Thread.Sleep(1000); // Pause to let the user read the feedback.
        }

        // --- "MODEL EVALUATION" ---
        // After training, we evaluate the performance (the player's score).
        PrintFinalScore(shuffledDeck.Count);
    }

    /// <summary>
    /// Prints the introductory text and instructions for the game.
    /// </summary>
    private static void PrintGameIntro()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
     ___  __      __   __   __   ___  __           ___  __  
    |__  |__)    /  ` /  \ /  ` |__  /  ` |  | |  |  |  /  \ 
    |___ |  \    \__, \__/ \__, |___ \__, \__/ |/\|  |  \__/ 
                                                            
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Flash Cards - Supervised Learning Edition!");
        Console.WriteLine("This game simulates how an AI learns from labeled data.");
        Console.WriteLine("Each flash card has a 'question' (the data) and an 'answer' (the label).");
        Console.WriteLine("Your goal is to provide the correct label for each piece of data.");
        Console.WriteLine("The feedback you get is the 'supervision'. Let's see your final accuracy!\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Creates the deck of flash cards (our "labeled dataset").
    /// </summary>
    /// <returns>A list of FlashCard objects.</returns>
    private static List<FlashCard> CreateAIDeck()
    {
        return new List<FlashCard>
        {
            new FlashCard("What type of AI search finds the shortest path first?", "BFS"),
            new FlashCard("In machine learning, what is the term for the labeled data used to teach an AI?", "Training Data"),
            new FlashCard("What algorithm is famously used for pathfinding in games, using a heuristic?", "A*"),
            new FlashCard("What does 'NLP' stand for?", "Natural Language Processing"),
            new FlashCard("An AI that plays Tic-Tac-Toe by analyzing future moves uses what algorithm?", "Minimax"),
            new FlashCard("What is the 'G' in 'GAN' (Generative Adversarial Network)?", "Generative"),
            new FlashCard("Learning from rewards and punishments is called...?", "Reinforcement Learning"),
            new FlashCard("Is 'classifying an email as spam or not' a regression or classification task?", "Classification")
        };
    }

    /// <summary>
    /// Prints the final score and performance summary.
    /// </summary>
    /// <param name="totalCards">The total number of cards in the deck.</param>
    private static void PrintFinalScore(int totalCards)
    {
        Console.WriteLine("\n--------------------------------------------------");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Training Session Complete!");
        
        double accuracy = (double)correctAnswers / totalCards * 100;

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"\n--- Model Performance ---");
        Console.WriteLine($"Correct Answers: {correctAnswers}");
        Console.WriteLine($"Total Questions: {totalCards}");
        Console.WriteLine($"Final Accuracy: {accuracy:F2}%");
        
        Console.ResetColor();
        Console.WriteLine("\nThanks for playing!");
    }
}
