using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

/// <summary>
/// Represents the possible moves in the game.
/// </summary>
public enum Move
{
    Rock,
    Paper,
    Scissors
}

/// <summary>
/// Main class for the Rock, Paper, Scissors game.
/// This program demonstrates basic game theory and a simple learning AI.
/// The AI analyzes the player's move patterns to predict their next choice.
/// </summary>
public class RockPaperScissors
{
    // Scores for the player and the AI
    private static int playerScore = 0;
    private static int aiScore = 0;

    // A dictionary to track the player's move patterns.
    // The key is the player's last move, and the value is a list of their subsequent moves.
    // This allows the AI to learn, for example, what the player tends to do after throwing "Rock".
    private static Dictionary<Move, List<Move>> playerMoveHistory = new Dictionary<Move, List<Move>>
    {
        { Move.Rock, new List<Move>() },
        { Move.Paper, new List<Move>() },
        { Move.Scissors, new List<Move>() }
    };

    // Stores the player's very last move to be used as a key for the history dictionary.
    private static Move? lastPlayerMove = null;
    private static Random random = new Random();

    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Rock, Paper, Scissors";
        Console.ForegroundColor = ConsoleColor.White;

        PrintGameIntro();

        // Main game loop
        while (true)
        {
            Console.WriteLine("--------------------------------------------------");
            Console.Write("Choose your move (r/p/s) or type 'q' to quit: ");
            string input = Console.ReadLine().ToLower();

            if (input == "q" || input == "quit")
            {
                break;
            }

            if (!TryParseMove(input, out Move playerMove))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid input. Please enter 'r' for Rock, 'p' for Paper, or 's' for Scissors.");
                Console.ResetColor();
                continue;
            }

            // Get the AI's move, which is predicted based on player history
            Move aiMove = GetAIMove();

            // Determine the winner of the round
            DetermineWinner(playerMove, aiMove);

            // Update the AI's knowledge base with the player's latest move
            UpdatePlayerHistory(playerMove);

            // Display the current score
            PrintScore();
        }

        Console.WriteLine("\nThanks for playing!");
    }

    /// <summary>
    /// Prints the introductory text and instructions for the game.
    /// </summary>
    private static void PrintGameIntro()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
    ___       __   __   __      __   ___  __       ___  __  
   |__  |    /  ` /  ` |__)    /  ` |__  |__)  /\   |  /  \ 
   |    |___ \__, \__, |  \    \__, |___ |  \ /~~\  |  \__/ 
                                                          
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Rock, Paper, Scissors!");
        Console.WriteLine("This isn't just a game of chance. You are playing against a learning AI.");
        Console.WriteLine("The AI will analyze your move patterns to predict your next choice.");
        Console.WriteLine("Can you be unpredictable enough to win?\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Parses the player's string input into a Move enum.
    /// </summary>
    /// <param name="input">The player's input string.</param>
    /// <param name="move">The resulting Move enum if parsing is successful.</param>
    /// <returns>True if parsing was successful, otherwise false.</returns>
    private static bool TryParseMove(string input, out Move move)
    {
        switch (input)
        {
            case "r":
            case "rock":
                move = Move.Rock;
                return true;
            case "p":
            case "paper":
                move = Move.Paper;
                return true;
            case "s":
            case "scissors":
                move = Move.Scissors;
                return true;
            default:
                move = default;
                return false;
        }
    }

    /// <summary>
    /// The core AI logic. Predicts the player's next move and chooses a counter.
    /// </summary>
    /// <returns>The AI's chosen move.</returns>
    private static Move GetAIMove()
    {
        // AI LEARNING LOGIC EXPLAINED:
        // 1. If we have a history of the player's moves, we check what they did after their *last* move.
        // 2. We find the most common move they made in that situation (e.g., after throwing 'Rock', they most often throw 'Paper').
        // 3. The AI assumes the player will repeat this pattern and chooses the winning counter-move.
        // 4. If there's no history for that situation, or it's the first round, the AI makes a random choice.

        if (lastPlayerMove.HasValue && playerMoveHistory[lastPlayerMove.Value].Any())
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("\nAI is thinking...");
            Thread.Sleep(500); // Simulate thinking

            // Find the most frequent move the player made after their last move.
            var moveFrequencies = playerMoveHistory[lastPlayerMove.Value]
                                  .GroupBy(m => m)
                                  .OrderByDescending(g => g.Count())
                                  .First();
            
            Move predictedPlayerMove = moveFrequencies.Key;
            
            Console.WriteLine($"AI Analysis: After you played '{lastPlayerMove.Value}', you most frequently play '{predictedPlayerMove}'.");
            
            // Choose the move that beats the predicted move.
            Move strategicMove = GetWinningMove(predictedPlayerMove);
            Console.WriteLine($"AI Prediction: I will play '{strategicMove}' to counter.");
            Console.ResetColor();
            return strategicMove;
        }

        // If there's no history, play randomly.
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("\nAI has no data on this situation... making a random move.");
        Console.ResetColor();
        return (Move)random.Next(0, 3);
    }

    /// <summary>
    /// Determines the winning move against a given move.
    /// </summary>
    /// <param name="move">The move to counter.</param>
    /// <returns>The move that wins against the input move.</returns>
    private static Move GetWinningMove(Move move)
    {
        switch (move)
        {
            case Move.Rock:
                return Move.Paper; // Paper covers Rock
            case Move.Paper:
                return Move.Scissors; // Scissors cut Paper
            case Move.Scissors:
                return Move.Rock; // Rock smashes Scissors
            default:
                throw new ArgumentOutOfRangeException();
        }
    }

    /// <summary>
    /// Determines the winner of a round and updates the score.
    /// </summary>
    /// <param name="playerMove">The player's move.</param>
    /// <param name="aiMove">The AI's move.</param>
    private static void DetermineWinner(Move playerMove, Move aiMove)
    {
        Console.WriteLine($"\nYou chose: {playerMove} | AI chose: {aiMove}");
        Thread.Sleep(500);

        if (playerMove == aiMove)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("It's a TIE!");
        }
        else if ((playerMove == Move.Rock && aiMove == Move.Scissors) ||
                 (playerMove == Move.Paper && aiMove == Move.Rock) ||
                 (playerMove == Move.Scissors && aiMove == Move.Paper))
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("You WIN this round!");
            playerScore++;
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("The AI WINS this round!");
            aiScore++;
        }
        Console.ResetColor();
    }

    /// <summary>
    /// Updates the AI's knowledge base with the player's most recent move.
    /// </summary>
    /// <param name="playerMove">The player's move in the current round.</param>
    private static void UpdatePlayerHistory(Move playerMove)
    {
        if (lastPlayerMove.HasValue)
        {
            // Add the current move to the history associated with the *previous* move.
            playerMoveHistory[lastPlayerMove.Value].Add(playerMove);
        }
        // Update the last move for the next round's prediction.
        lastPlayerMove = playerMove;
    }

    /// <summary>
    /// Prints the current score to the console.
    /// </summary>
    private static void PrintScore()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"\nSCORE: Player - {playerScore} | AI - {aiScore}");
        Console.ResetColor();
    }
}