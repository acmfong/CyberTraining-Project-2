using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

/// <summary>
/// Represents a player in the game.
/// </summary>
public class Player
{
    public string Name { get; }
    public char Marker { get; }
    public int Position { get; set; }

    public Player(string name, char marker)
    {
        Name = name;
        Marker = marker;
        Position = 0;
    }
}

/// <summary>
/// Manages the game board, including its size and special spaces.
/// </summary>
public class Board
{
    public int Size { get; }
    // Key = start space, Value = end space.
    private readonly Dictionary<int, int> _specialSpaces;

    public Board(int size)
    {
        Size = size;
        _specialSpaces = new Dictionary<int, int>
        {
            { 3, 15 },  // Ladder
            { 12, 22 }, // Ladder
            { 28, 5 },  // Chute
            { 18, 9 }   // Chute
        };
    }

    /// <summary>
    /// Checks if a position is a special space and returns the destination.
    /// </summary>
    /// <returns>The destination if it's a special space, otherwise the original position.</returns>
    public int GetSpecialTransition(int position)
    {
        return _specialSpaces.TryGetValue(position, out int destination) ? destination : position;
    }

    /// <summary>
    /// Draws the entire game board with player positions.
    /// </summary>
    public void Draw(params Player[] players)
    {
        Console.Clear();
        Console.WriteLine($"Goal: Reach or pass space {Size}.");
        foreach (var player in players)
        {
            Console.WriteLine($"- {player.Name} ({player.Marker}) is at position {player.Position}");
        }
        Console.WriteLine();

        Console.Write("[Start]");
        for (int i = 1; i <= Size; i++)
        {
            var playerAtPos = players.FirstOrDefault(p => p.Position == i);
            if (playerAtPos != null)
            {
                Console.ForegroundColor = playerAtPos.Marker == 'P' ? ConsoleColor.Green : ConsoleColor.Red;
                Console.Write($"[{playerAtPos.Marker}]");
                Console.ResetColor();
            }
            else if (_specialSpaces.TryGetValue(i, out int destination))
            {
                Console.ForegroundColor = destination > i ? ConsoleColor.Cyan : ConsoleColor.Yellow;
                Console.Write(destination > i ? "[L]" : "[C]"); // Ladder or Chute
                Console.ResetColor();
            }
            else
            {
                Console.Write("[_]");
            }
        }
        Console.WriteLine("[End]");
    }
}

/// <summary>
/// Main class that orchestrates the game logic and loop.
/// </summary>
public class Game
{
    private readonly Player _human;
    private readonly Player _ai;
    private readonly Board _board;
    private readonly Random _random;

    public Game()
    {
        _human = new Player("Human", 'P');
        _ai = new Player("AI", 'A');
        _board = new Board(30);
        _random = new Random();
    }

    /// <summary>
    /// Starts and runs the main game loop.
    /// </summary>
    public void Run()
    {
        PrintGameIntro();

        while (true)
        {
            TakeTurn(_human);
            if (CheckForWinner(_human)) break;

            TakeTurn(_ai);
            if (CheckForWinner(_ai)) break;
        }

        PrintFinalMessage();
    }

    /// <summary>
    /// Manages a single turn for a given player.
    /// </summary>
    private void TakeTurn(Player currentPlayer)
    {
        _board.Draw(_human, _ai);
        
        Console.WriteLine($"\nIt's {currentPlayer.Name}'s turn.");
        if (currentPlayer == _human)
        {
            Console.WriteLine("Press any key to roll the die...");
            Console.ReadKey(true);
        }
        else
        {
            Console.WriteLine("AI is thinking...");
            Thread.Sleep(1000);
        }

        // --- THE ACTION ---
        int roll = _random.Next(1, 7);
        Console.WriteLine($"{currentPlayer.Name} rolled a: {roll}");
        Thread.Sleep(500);

        // --- THE STATE TRANSITION ---
        int previousState = currentPlayer.Position;
        currentPlayer.Position += roll;
        Console.WriteLine($"{currentPlayer.Name} moved from space {previousState} to {currentPlayer.Position}.");
        Thread.Sleep(1000);

        // Check for special deterministic transitions (ladders/chutes).
        int newPosition = _board.GetSpecialTransition(currentPlayer.Position);
        if (newPosition != currentPlayer.Position)
        {
            bool isLadder = newPosition > currentPlayer.Position;
            Console.ForegroundColor = isLadder ? ConsoleColor.Green : ConsoleColor.Red;
            Console.WriteLine(isLadder
                ? $"\nLADDER! {currentPlayer.Name} climbed from {currentPlayer.Position} to {newPosition}!"
                : $"\nCHUTE! {currentPlayer.Name} slid from {currentPlayer.Position} down to {newPosition}!");
            
            currentPlayer.Position = newPosition;
            Console.ResetColor();
            Thread.Sleep(1500);
        }
    }
    
    private bool CheckForWinner(Player player)
    {
        return player.Position >= _board.Size;
    }

    private void PrintGameIntro()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
 __  __    _    ____  _   _     __  __  _   _ _   _ _   _ 
|  \/  |  / \  |  _ \| | | |   |  \/  || | | | \ | | | | |
| |\/| | / _ \ | |_) | | | |   | |\/| || | | |  \| | | | |
| |  | |/ ___ \|  _ <| |_| |   | |  | || |_| | |\  | |_| |
|_|  |_/_/   \_\_| \_\\___/    |_|  |_| \___/|_| \_|\___/ 
                                                        
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Roll and Move!");
        Console.WriteLine("This game simulates a 'Markov Decision Process' (MDP).");
        Console.WriteLine("You are racing against an AI. First to the end wins!");
        Console.WriteLine("\n- The board is a set of 'States'. Your position is the current state.");
        Console.WriteLine("- Rolling the die is an 'Action'.");
        Console.WriteLine("- Moving to a new space is a 'State Transition'.");
        Console.WriteLine("\nNotice how your next position depends ONLY on where you are now and your dice roll,");
        Console.WriteLine("not on how you got there. This is the 'Markov Property'.\n");
        Console.ResetColor();
        Console.WriteLine("Press any key to start...");
        Console.ReadKey(true);
    }

    private void PrintFinalMessage()
    {
        _board.Draw(_human, _ai);
        Player winner = _human.Position >= _board.Size ? _human : _ai;
        
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"\n\n{winner.Name} reached space {winner.Position} and finished the game!");
        Console.WriteLine($"Congratulations, {winner.Name}! You win!");
        Console.ResetColor();
        Console.WriteLine("\nThanks for playing!");
    }
}

/// <summary>
/// The main entry point for the program.
/// </summary>
public class Program
{
    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Markov Decision Processes";
        Console.CursorVisible = false;
        
        var game = new Game();
        game.Run();
        
        Console.CursorVisible = true;
    }
}
