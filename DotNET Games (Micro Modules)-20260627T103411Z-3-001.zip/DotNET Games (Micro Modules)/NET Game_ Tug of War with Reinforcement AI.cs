using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

/// <summary>
/// Main class for the Tug of War game.
/// This program simulates reward-based learning. The AI tracks the game state
/// (the rope's position) and receives positive or negative reinforcement signals
/// based on the outcome of each turn, adjusting its strategy accordingly.
/// </summary>
public class TugOfWarGame
{
    // The position of the rope's center marker. Negative is player's side, positive is AI's side.
    private static int ropePosition = 0;
    private const int WIN_POSITION = 10; // Position needed to win

    // AI's policy: state -> action (pull strength) -> weight (likelihood of choosing)
    // This is the AI's "brain" where it stores what it has learned.
    private static Dictionary<int, Dictionary<int, double>> aiPolicy = new Dictionary<int, Dictionary<int, double>>();
    
    private static Random random = new Random();

    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Reward-Based Tug of War";
        Console.ForegroundColor = ConsoleColor.White;

        PrintGameIntro();
        InitializeAIPolicy();

        // Main game loop
        while (Math.Abs(ropePosition) < WIN_POSITION)
        {
            DisplayRope();
            
            int playerPull = GetPlayerPull();
            int aiPull = GetAIPull();

            // --- REINFORCEMENT LEARNING STEP ---
            // 1. Observe the current state (ropePosition).
            // 2. The AI takes an action (aiPull).
            // 3. We determine the outcome and the reward.
            
            int previousPosition = ropePosition;
            int pullDifference = aiPull - playerPull;
            ropePosition += pullDifference;

            // Clamp the rope position so it doesn't go past the win boundaries
            ropePosition = Math.Max(-WIN_POSITION, Math.Min(WIN_POSITION, ropePosition));

            Console.WriteLine($"\nYou pulled with strength {playerPull}. AI pulled with strength {aiPull}.");
            
            // 4. Update the AI's policy based on the reward.
            UpdateAIPolicy(previousPosition, aiPull, ropePosition);

            Thread.Sleep(1000);
        }

        DisplayRope();
        DeclareWinner();
        Console.WriteLine("\nThanks for playing!");
    }

    /// <summary>
    /// Prints the introductory text and instructions.
    /// </summary>
    private static void PrintGameIntro()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
     _____ _    _   _    _    __      __      __   ___  __  
    |_   _| |  | | | |  | |  /  \ \  / /  `   /  ` |__  |__) 
      | | | |  | | | |  | |  \__/  \/  \__,   \__, |___ |  \ 
                                                             
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Tug of War!");
        Console.WriteLine("This game simulates an AI using 'Reward-Based Learning'.");
        Console.WriteLine("The AI learns by tracking the game state (the rope's position).");
        Console.WriteLine("A good move gives a 'positive reward', making that move more likely in the future.");
        Console.WriteLine("A bad move gives a 'negative reward' (punishment). Can you outsmart the learning AI?\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Initializes the AI's policy with equal weights for all actions in all states.
    /// </summary>
    private static void InitializeAIPolicy()
    {
        for (int state = -WIN_POSITION; state <= WIN_POSITION; state++)
        {
            aiPolicy[state] = new Dictionary<int, double>();
            for (int action = 1; action <= 5; action++)
            {
                aiPolicy[state][action] = 1.0; // Start with equal preference for all pulls
            }
        }
    }

    /// <summary>
    /// Displays the current state of the rope.
    /// </summary>
    private static void DisplayRope()
    {
        Console.WriteLine("\n--------------------------------------------------");
        StringBuilder ropeBuilder = new StringBuilder();
        ropeBuilder.Append("Player [-P-] ");
        
        // Build the rope visual
        int displayWidth = WIN_POSITION * 2 + 1;
        for (int i = -WIN_POSITION; i <= WIN_POSITION; i++)
        {
            if (i == ropePosition)
            {
                ropeBuilder.Append("O"); // The center marker
            }
            else
            {
                ropeBuilder.Append("~");
            }
        }

        ropeBuilder.Append(" [-AI-]");
        Console.WriteLine(ropeBuilder.ToString());
    }

    /// <summary>
    /// Prompts the player to enter their pull strength and validates it.
    /// </summary>
    /// <returns>The player's chosen pull strength (1-5).</returns>
    private static int GetPlayerPull()
    {
        while (true)
        {
            Console.Write("\nChoose your pull strength (1-5): ");
            if (int.TryParse(Console.ReadLine(), out int pull) && pull >= 1 && pull <= 5)
            {
                return pull;
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Invalid input. Please enter a number between 1 and 5.");
            Console.ResetColor();
        }
    }

    /// <summary>
    /// The AI chooses its pull strength based on its learned policy for the current state.
    /// </summary>
    /// <returns>The AI's chosen pull strength.</returns>
    private static int GetAIPull()
    {
        var actions = aiPolicy[ropePosition];
        double totalWeight = actions.Values.Sum();
        double randomChoice = random.NextDouble() * totalWeight;

        double cumulativeWeight = 0;
        foreach (var action in actions)
        {
            cumulativeWeight += action.Value;
            if (randomChoice < cumulativeWeight)
            {
                return action.Key; // Choose action based on weighted probability
            }
        }
        return actions.Keys.Last(); // Fallback
    }

    /// <summary>
    /// Updates the AI's policy based on the outcome of the turn.
    /// This is the core of the reinforcement learning.
    /// </summary>
    /// <param name="previousState">The rope position before the pull.</param>
    /// <param name="actionTaken">The pull strength the AI used.</param>
    /// <param name="newState">The rope position after the pull.</param>
    private static void UpdateAIPolicy(int previousState, int actionTaken, int newState)
    {
        double reward = newState - previousState; // Positive reward if rope moved to AI side

        if (reward > 0)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"AI received a POSITIVE reward. It likes the move '{actionTaken}' in this situation.");
            // Increase the weight for the successful action
            aiPolicy[previousState][actionTaken] *= 1.1; 
        }
        else if (reward < 0)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"AI received a NEGATIVE reward. It dislikes the move '{actionTaken}' in this situation.");
            // Decrease the weight for the unsuccessful action
            aiPolicy[previousState][actionTaken] *= 0.9;
        }
        else
        {
             Console.ForegroundColor = ConsoleColor.Yellow;
             Console.WriteLine("AI received a NEUTRAL reward. No change in strategy.");
        }
        Console.ResetColor();
    }

    /// <summary>
    /// Declares the winner of the game based on the final rope position.
    /// </summary>
    private static void DeclareWinner()
    {
        Console.WriteLine("\n==========================================");
        if (ropePosition <= -WIN_POSITION)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("You pulled the rope all the way! YOU WIN!");
        }
        else if (ropePosition >= WIN_POSITION)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("The AI pulled the rope all the way! THE AI WINS!");
        }
        Console.ResetColor();
        Console.WriteLine("==========================================");
    }
}
