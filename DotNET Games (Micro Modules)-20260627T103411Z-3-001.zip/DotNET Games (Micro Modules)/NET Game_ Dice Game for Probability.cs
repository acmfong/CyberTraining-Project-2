using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

/// <summary>
/// Main class for the Dice Game.
/// This program demonstrates concepts of probability, random number generation,
/// and stochastic processes by simulating the rolling of two dice.
/// It educates the player by showing the probability distribution of all possible outcomes.
/// </summary>
public class DiceGame
{
    private static int playerScore = 0;
    private static int roundsPlayed = 0;
    private static Random random = new Random();

    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Probability Dice";
        Console.ForegroundColor = ConsoleColor.White;

        PrintGameIntro();

        // Main game loop
        while (true)
        {
            Console.WriteLine("--------------------------------------------------");
            
            // Display the probabilities before the player makes a choice
            DisplayProbabilityDistribution();

            int playerBet = GetPlayerBet();
            if (playerBet == -1) // Sentinel value for quitting
            {
                break;
            }

            // Simulate the dice roll
            int die1 = random.Next(1, 7);
            int die2 = random.Next(1, 7);
            int total = die1 + die2;

            Console.WriteLine("\nRolling the dice...");
            Thread.Sleep(700);

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"Die 1: [{die1}]");
            Console.WriteLine($"Die 2: [{die2}]");
            Console.WriteLine($"Total: {total}");
            Console.ResetColor();

            // Determine the outcome
            if (total == playerBet)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\nCongratulations! You guessed correctly and won the round!");
                playerScore++;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\nSorry, the total was {total}. Better luck next time!");
            }
            roundsPlayed++;
            Console.ResetColor();

            PrintScore();

            Console.Write("\nPlay again? (y/n): ");
            if (Console.ReadLine().ToLower() != "y")
            {
                break;
            }
        }

        Console.WriteLine("\nThanks for playing!");
    }

    /// <summary>
    /// Prints the introductory text and instructions for the game.
    /// </summary>
    private static void PrintGameIntro()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
     ___  _  ___  ___  ___     ___   __   __      __   ___  __  
    |__  / \| |__ |__  |__     |__  /  ` /  ` |__) /  ` |__  |__) 
    |    | | |   |___ |___    |    \__, \__, |  \ \__, |___ |  \ 
                                                               
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to the Probability Dice Game!");
        Console.WriteLine("This game demonstrates how probability works with two six-sided dice.");
        Console.WriteLine("Before each roll, you'll see the chances of each possible total (from 2 to 12).");
        Console.WriteLine("Notice that sums like 7 are much more common than 2 or 12.");
        Console.WriteLine("This concept is key to understanding random events and stochastic processes.\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Calculates and displays the probability distribution for the sum of two dice.
    /// </summary>
    private static void DisplayProbabilityDistribution()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Probability of each possible total for two 6-sided dice:");
        Console.ResetColor();
        Console.WriteLine("┌───────┬──────────────┬───────────────┐");
        Console.WriteLine("│ Total │ Combinations │ Probability   │");
        Console.WriteLine("├───────┼──────────────┼───────────────┤");

        // There are 36 possible outcomes when rolling two dice (6 * 6)
        const int totalOutcomes = 36;
        for (int i = 2; i <= 12; i++)
        {
            int combinations = 0;
            // Calculate how many ways each total can be made
            for (int d1 = 1; d1 <= 6; d1++)
            {
                for (int d2 = 1; d2 <= 6; d2++)
                {
                    if (d1 + d2 == i)
                    {
                        combinations++;
                    }
                }
            }
            double probability = (double)combinations / totalOutcomes * 100;
            Console.WriteLine($"│ {i,-5} │ {combinations,-12} │ {probability,12:F2}% │");
        }
        Console.WriteLine("└───────┴──────────────┴───────────────┘");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Educational Note: This table represents a stochastic process. The outcome is random,");
        Console.WriteLine("but the probability of each event is fixed. 'Entropy' is a measure of the uncertainty");
        Console.WriteLine("of the outcome. Since 7 is the most likely, guessing 7 has the least uncertainty.\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Prompts the player to enter their bet and validates the input.
    /// </summary>
    /// <returns>The player's bet (2-12) or -1 to quit.</returns>
    private static int GetPlayerBet()
    {
        while (true)
        {
            Console.Write("Place your bet on the total (2-12), or type 'q' to quit: ");
            string input = Console.ReadLine();

            if (input.ToLower() == "q" || input.ToLower() == "quit")
            {
                return -1;
            }

            if (int.TryParse(input, out int bet) && bet >= 2 && bet <= 12)
            {
                return bet;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid input. Please enter a number between 2 and 12.");
                Console.ResetColor();
            }
        }
    }

    /// <summary>
    /// Prints the current score to the console.
    /// </summary>
    private static void PrintScore()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"\nSCORE: You have won {playerScore} out of {roundsPlayed} rounds.");
        Console.ResetColor();
    }
}
