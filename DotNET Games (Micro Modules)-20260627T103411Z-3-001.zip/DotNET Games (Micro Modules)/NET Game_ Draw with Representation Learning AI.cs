using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

/// <summary>
/// Represents the drawing canvas.
/// </summary>
public class Canvas
{
    private readonly char[,] _grid;
    public int Width { get; }
    public int Height { get; }

    public Canvas(int width, int height)
    {
        Width = width;
        Height = height;
        _grid = new char[width, height];
        Clear();
    }

    public void Clear()
    {
        for (int y = 0; y < Height; y++)
        {
            for (int x = 0; x < Width; x++)
            {
                _grid[x, y] = '.';
            }
        }
    }

    public void SetPixel(int x, int y, char character)
    {
        if (x >= 0 && x < Width && y >= 0 && y < Height)
        {
            _grid[x, y] = character;
        }
    }

    public char GetPixel(int x, int y)
    {
        return _grid[x, y];
    }

    public void Display(int cursorX, int cursorY)
    {
        Console.SetCursorPosition(0, 5); // Start drawing below the instructions
        for (int y = 0; y < Height; y++)
        {
            for (int x = 0; x < Width; x++)
            {
                if (x == cursorX && y == cursorY)
                {
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                }
                
                Console.Write(_grid[x, y]);

                if (x == cursorX && y == cursorY)
                {
                    Console.ResetColor();
                }
                Console.Write(" ");
            }
            Console.WriteLine();
        }
    }
}

/// <summary>
/// Main class for the Draw game. Simulates representation learning and abstraction.
/// </summary>
public class DrawGame
{
    private readonly Canvas _canvas;
    private readonly Dictionary<string, Func<Canvas, int>> _aiAnalyzers;
    private readonly List<string> _drawTargets;
    private readonly Random _random;

    public DrawGame()
    {
        _canvas = new Canvas(15, 10);
        _random = new Random();
        _drawTargets = new List<string> { "House", "Tree", "Sun" };

        // This dictionary represents the AI's "knowledge".
        // Each function is a simple feature detector for a specific concept.
        // This simulates how a trained model learns to look for specific patterns.
        _aiAnalyzers = new Dictionary<string, Func<Canvas, int>>
        {
            { "House", AnalyzeHouse },
            { "Tree", AnalyzeTree },
            { "Sun", AnalyzeSun }
        };
    }

    public void Run()
    {
        PrintGameIntro();
        
        string target = _drawTargets[_random.Next(_drawTargets.Count)];
        
        PlayerDrawLoop(target);
        
        AnalyzeDrawing(target);
    }

    /// <summary>
    /// The main loop where the player draws on the canvas.
    /// </summary>
    private void PlayerDrawLoop(string target)
    {
        int cursorX = _canvas.Width / 2;
        int cursorY = _canvas.Height / 2;

        while (true)
        {
            Console.Clear();
            Console.WriteLine($"Your task: Draw a '{target}'");
            Console.WriteLine("Use arrow keys to move, any other key to draw that character.");
            Console.WriteLine("Press 'Enter' when you are finished drawing.");
            _canvas.Display(cursorX, cursorY);

            ConsoleKeyInfo keyInfo = Console.ReadKey(true);

            if (keyInfo.Key == ConsoleKey.Enter) break;

            switch (keyInfo.Key)
            {
                case ConsoleKey.UpArrow: cursorY = Math.Max(0, cursorY - 1); break;
                case ConsoleKey.DownArrow: cursorY = Math.Min(_canvas.Height - 1, cursorY + 1); break;
                case ConsoleKey.LeftArrow: cursorX = Math.Max(0, cursorX - 1); break;
                case ConsoleKey.RightArrow: cursorX = Math.Min(_canvas.Width - 1, cursorX + 1); break;
                default:
                    _canvas.SetPixel(cursorX, cursorY, keyInfo.KeyChar);
                    break;
            }
        }
    }

    /// <summary>
    /// The AI analyzes the player's drawing and provides feedback.
    /// </summary>
    private void AnalyzeDrawing(string target)
    {
        Console.Clear();
        Console.WriteLine("AI is analyzing your representation...");
        _canvas.Display(-1, -1); // Display without cursor
        Thread.Sleep(2000);

        int bestScore = -1;
        string bestGuess = "nothing";

        foreach (var analyzer in _aiAnalyzers)
        {
            int score = analyzer.Value(_canvas);
            Console.WriteLine($"Analyzing for '{analyzer.Key}'... Found {score} matching features.");
            if (score > bestScore)
            {
                bestScore = score;
                bestGuess = analyzer.Key;
            }
            Thread.Sleep(500);
        }

        Console.WriteLine("\n--- AI Feedback Loop ---");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine($"Based on the symbols, my best guess is that you drew a: {bestGuess}");
        
        if (bestGuess == target)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Success! My analysis matches your intent. Your representation was effective.");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("My analysis does not match your intent. The symbolic representation could be clearer.");
        }
        Console.ResetColor();
    }

    // --- AI Feature Detectors ---

    private int AnalyzeHouse(Canvas canvas)
    {
        int score = 0;
        // Looks for a roof '^' above walls '|'
        for (int y = 0; y < canvas.Height - 1; y++)
        {
            for (int x = 0; x < canvas.Width; x++)
            {
                if (canvas.GetPixel(x, y) == '^' && (canvas.GetPixel(x, y + 1) == '|' || canvas.GetPixel(x, y + 1) == '#'))
                    score += 5;
                if (canvas.GetPixel(x, y) == '#') score++;
            }
        }
        return score;
    }

    private int AnalyzeTree(Canvas canvas)
    {
        int score = 0;
        // Looks for a trunk '|' below leaves '#' or 'O'
        for (int y = 1; y < canvas.Height; y++)
        {
            for (int x = 0; x < canvas.Width; x++)
            {
                if (canvas.GetPixel(x, y) == '|' && (canvas.GetPixel(x, y - 1) == '#' || canvas.GetPixel(x, y - 1) == 'O'))
                    score += 5;
                if (canvas.GetPixel(x, y) == '#') score++;
            }
        }
        return score;
    }

    private int AnalyzeSun(Canvas canvas)
    {
        int score = 0;
        // Looks for a center 'O' or '*' with rays '/' or '\' around it
        for (int y = 1; y < canvas.Height - 1; y++)
        {
            for (int x = 1; x < canvas.Width - 1; x++)
            {
                char center = canvas.GetPixel(x, y);
                if (center == 'O' || center == '*' || center == 'o')
                {
                    score += 2;
                    if (canvas.GetPixel(x - 1, y) == '-') score++;
                    if (canvas.GetPixel(x + 1, y) == '-') score++;
                    if (canvas.GetPixel(x, y - 1) == '|') score++;
                    if (canvas.GetPixel(x, y + 1) == '|') score++;
                    if (canvas.GetPixel(x - 1, y - 1) == '\\') score += 2;
                    if (canvas.GetPixel(x + 1, y + 1) == '\\') score += 2;
                }
            }
        }
        return score;
    }

    private void PrintGameIntro()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
 ____  ____    _    __        __
|  _ \|  _ \  / \   \ \      / /
| | | | | | |/ _ \   \ \ /\ / / 
| |_| | |_| / ___ \   \ V  V /  
|____/|____/_/   \_\   \_/\_/   
                                
        ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Welcome to Draw!");
        Console.WriteLine("This game simulates 'Representation Learning'.");
        Console.WriteLine("You must represent a concept using simple symbols (ASCII art).");
        Console.WriteLine("An AI will then analyze your drawing and provide feedback.\n");
        Console.ResetColor();
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Console.Title = "AI Learning Game: Representation Learning";
        var game = new DrawGame();
        game.Run();
        Console.WriteLine("\nThanks for playing!");
    }
}
