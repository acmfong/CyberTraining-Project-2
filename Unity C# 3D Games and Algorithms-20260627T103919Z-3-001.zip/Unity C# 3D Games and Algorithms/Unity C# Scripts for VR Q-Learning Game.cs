// ----------------- SCRIPT 1: AgentController.cs -----------------
// Attach this to your main 'GameManager' GameObject.
// It orchestrates the entire training and demonstration process.
// ----------------------------------------------------------------

using UnityEngine;
using System.Collections;

public class AgentController : MonoBehaviour
{
    [Header("References")]
    public GridManager gridManager;
    public QLearningAgent agent;

    [Header("Training Parameters")]
    [Tooltip("Number of episodes to run for training.")]
    public int maxEpisodes = 2000;
    [Tooltip("Maximum steps the agent can take in one episode.")]
    public int maxStepsPerEpisode = 100;

    [Header("Control")]
    [Tooltip("How fast the simulation runs during training. Lower is slower.")]
    [Range(0.01f, 0.5f)]
    public float simulationSpeed = 0.05f;

    private int currentEpisode = 0;

    /// <summary>
    /// Public method to be called by VR UI to start the training process.
    /// </summary>
    public void StartTraining()
    {
        Debug.Log("Starting Q-Learning Training...");
        StopAllCoroutines(); // Stop any previous routines
        StartCoroutine(RunTrainingLoop());
    }

    /// <summary>
    /// The main training loop that runs through all episodes.
    /// </summary>
    private IEnumerator RunTrainingLoop()
    {
        for (currentEpisode = 0; currentEpisode < maxEpisodes; currentEpisode++)
        {
            gridManager.ResetEnvironment();
            int state = gridManager.GetStateForPosition(agent.transform.position);

            for (int step = 0; step < maxStepsPerEpisode; step++)
            {
                QLearningAgent.Action action = agent.ChooseAction(state);
                Vector3 nextPosition = agent.GetNextPosition(action);
                GridManager.TileInfo nextTileInfo = gridManager.GetTileInfoForPosition(nextPosition);
                
                agent.transform.position = nextPosition;
                int nextState = gridManager.GetStateForPosition(nextPosition);
                float reward = nextTileInfo.reward;

                agent.Learn(state, action, reward, nextState);
                state = nextState;

                yield return new WaitForSeconds(simulationSpeed);

                if (nextTileInfo.isTerminal) break;
            }
        }
        Debug.Log("Training complete!");
        DemonstrateOptimalPath();
    }

    /// <summary>
    /// After training, this method makes the agent follow the best-known path.
    /// </summary>
    public void DemonstrateOptimalPath()
    {
        StopAllCoroutines();
        StartCoroutine(RunDemonstration());
    }

    private IEnumerator RunDemonstration()
    {
        Debug.Log("Demonstrating Optimal Path...");
        gridManager.ResetEnvironment();
        int state = gridManager.GetStateForPosition(agent.transform.position);

        for (int step = 0; step < maxStepsPerEpisode; step++)
        {
            QLearningAgent.Action action = agent.GetBestAction(state);
            Vector3 nextPosition = agent.GetNextPosition(action);
            GridManager.TileInfo nextTileInfo = gridManager.GetTileInfoForPosition(nextPosition);

            agent.transform.position = nextPosition;
            state = gridManager.GetStateForPosition(nextPosition);
            
            yield return new WaitForSeconds(0.2f); // Slower for demonstration

            if (nextTileInfo.isTerminal)
            {
                Debug.Log("Demonstration finished.");
                break;
            }
        }
    }
}


// ----------------- SCRIPT 2: QLearningAgent.cs ------------------
// Attach this to your 'Agent' prefab.
// This is the "brain" of the AI, containing the Q-table and learning logic.
// ----------------------------------------------------------------

using System.Collections.Generic;
using UnityEngine;

public class QLearningAgent : MonoBehaviour
{
    [Header("Q-Learning Parameters")]
    [Range(0, 1)] public float learningRate = 0.1f;
    [Range(0, 1)] public float discountFactor = 0.9f;
    [Range(0, 1)] public float epsilon = 1.0f;
    public float epsilonDecay = 0.999f;
    
    public enum Action { Up, Down, Left, Right }
    
    private float[,] qTable;
    private int numStates;
    private int numActions;
    private GridManager gridManager;

    public void Initialize(int states, int actions, GridManager manager)
    {
        numStates = states;
        numActions = actions;
        gridManager = manager;
        qTable = new float[numStates, numActions];
    }

    public Action ChooseAction(int state)
    {
        if (Random.value < epsilon)
        {
            return (Action)Random.Range(0, numActions); // Explore
        }
        return GetBestAction(state); // Exploit
    }

    public Action GetBestAction(int state)
    {
        float maxQValue = float.MinValue;
        List<Action> tiedActions = new List<Action>();

        for (int i = 0; i < numActions; i++)
        {
            if (qTable[state, i] > maxQValue)
            {
                maxQValue = qTable[state, i];
                tiedActions.Clear();
                tiedActions.Add((Action)i);
            }
            else if (qTable[state, i] == maxQValue)
            {
                tiedActions.Add((Action)i);
            }
        }
        return tiedActions[Random.Range(0, tiedActions.Count)];
    }

    public void Learn(int state, Action action, float reward, int nextState)
    {
        float maxQNext = float.MinValue;
        for (int i = 0; i < numActions; i++)
        {
            if (qTable[nextState, i] > maxQNext) maxQNext = qTable[nextState, i];
        }

        float currentQ = qTable[state, (int)action];
        float newQ = currentQ + learningRate * (reward + discountFactor * maxQNext - currentQ);
        qTable[state, (int)action] = newQ;
    }

    public Vector3 GetNextPosition(Action action)
    {
        Vector3 nextPos = transform.position;
        switch (action)
        {
            case Action.Up:    nextPos.z += 1; break;
            case Action.Down:  nextPos.z -= 1; break;
            case Action.Left:  nextPos.x -= 1; break;
            case Action.Right: nextPos.x += 1; break;
        }
        return gridManager.ClampPosition(nextPos);
    }
    
    public void DecayEpsilon()
    {
        if (epsilon > 0.01f) epsilon *= epsilonDecay;
    }
}


// ----------------- SCRIPT 3: GridManager.cs ---------------------
// Attach this to your main 'GameManager' GameObject.
// It procedurally generates the 3D grid world.
// ----------------------------------------------------------------

using UnityEngine;

public class GridManager : MonoBehaviour
{
    [Header("Grid Dimensions")]
    public int width = 10;
    public int height = 10;

    [Header("Prefabs")]
    public GameObject floorPrefab;
    public GameObject wallPrefab;
    public GameObject goalPrefab;
    public GameObject hazardPrefab;
    public QLearningAgent agentPrefab;
    
    private TileInfo[,] grid;
    private QLearningAgent agentInstance;
    private Vector3 startPosition;

    void Awake()
    {
        GenerateGrid();
        InitializeAgent();
    }

    private void GenerateGrid()
    {
        grid = new TileInfo[width, height];
        for (int x = 0; x < width; x++)
        {
            for (int z = 0; z < height; z++)
            {
                Vector3 position = new Vector3(x, 0, z);
                GameObject tileObject;
                TileInfo.TileType type;
                float reward;
                bool isTerminal = false;

                if (x == 0 || x == width - 1 || z == 0 || z == height - 1 || (x > 2 && x < 7 && z == 5))
                {
                    tileObject = Instantiate(wallPrefab, position, Quaternion.identity, transform);
                    type = TileInfo.TileType.Wall;
                    reward = -10.0f;
                }
                else if (x == width - 2 && z == height - 2)
                {
                    tileObject = Instantiate(goalPrefab, position, Quaternion.identity, transform);
                    type = TileInfo.TileType.Goal;
                    reward = 100.0f;
                    isTerminal = true;
                }
                else if ((x == 4 && z == 4) || (x == 2 && z == 7))
                {
                    tileObject = Instantiate(hazardPrefab, position, Quaternion.identity, transform);
                    type = TileInfo.TileType.Hazard;
                    reward = -50.0f;
                    isTerminal = true;
                }
                else
                {
                    tileObject = Instantiate(floorPrefab, position, Quaternion.identity, transform);
                    type = TileInfo.TileType.Normal;
                    reward = -0.1f;
                }
                
                grid[x, z] = new TileInfo(type, reward, isTerminal, position);
            }
        }
        startPosition = new Vector3(1, 0.5f, 1);
    }

    private void InitializeAgent()
    {
        agentInstance = Instantiate(agentPrefab, startPosition, Quaternion.identity);
        agentInstance.Initialize(width * height, 4, this);
        GetComponent<AgentController>().agent = agentInstance;
    }

    public void ResetEnvironment()
    {
        agentInstance.transform.position = startPosition;
        agentInstance.DecayEpsilon();
    }

    public int GetStateForPosition(Vector3 position)
    {
        int x = Mathf.RoundToInt(position.x);
        int z = Mathf.RoundToInt(position.z);
        return z * width + x;
    }

    public TileInfo GetTileInfoForPosition(Vector3 position)
    {
        int x = Mathf.RoundToInt(position.x);
        int z = Mathf.RoundToInt(position.z);
        x = Mathf.Clamp(x, 0, width - 1);
        z = Mathf.Clamp(z, 0, height - 1);
        return grid[x, z];
    }
    
    public Vector3 ClampPosition(Vector3 position)
    {
        position.x = Mathf.Clamp(Mathf.RoundToInt(position.x), 0, width - 1);
        position.z = Mathf.Clamp(Mathf.RoundToInt(position.z), 0, height - 1);
        position.y = startPosition.y;
        return position;
    }
    
    public struct TileInfo
    {
        public enum TileType { Normal, Wall, Goal, Hazard }
        public TileType type;
        public float reward;
        public bool isTerminal;
        public Vector3 position;

        public TileInfo(TileType t, float r, bool term, Vector3 pos)
        {
            type = t; reward = r; isTerminal = term; position = pos;
        }
    }
}


// ----------------- SCRIPT 4: VREnvironmentInteractor.cs ---------
// Attach this to a 'VR_UI_Manager' GameObject.
// It connects your VR UI buttons to the game logic.
// ----------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;

public class VREnvironmentInteractor : MonoBehaviour
{
    [Header("References")]
    public AgentController agentController;
    public Text statusText; // Assign a TextMeshPro or UI Text component

    public void TriggerTraining()
    {
        if (agentController != null)
        {
            Debug.Log("VR Button: Training Triggered.");
            agentController.StartTraining();
            if(statusText != null) statusText.text = "Status: Training...";
        }
    }

    public void TriggerDemonstration()
    {
        if (agentController != null)
        {
            Debug.Log("VR Button: Demonstration Triggered.");
            agentController.DemonstrateOptimalPath();
            if(statusText != null) statusText.text = "Status: Demonstrating Path";
        }
    }
}

