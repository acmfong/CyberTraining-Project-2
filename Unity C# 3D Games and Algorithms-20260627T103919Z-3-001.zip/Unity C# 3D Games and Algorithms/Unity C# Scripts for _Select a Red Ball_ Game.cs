// ----------------- SCRIPT 1: ObjectSelectionAgent.cs -----------------
// Attach this to the Agent GameObject.
// This is the agent's "brain" that learns to select the correct object.
// ---------------------------------------------------------------------

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using System.Collections.Generic;

public class ObjectSelectionAgent : Agent
{
    [Tooltip("The manager that controls the environment and objects.")]
    public EnvironmentManager envManager;
    [Tooltip("The 'hand' or pointer of the agent that moves to select objects.")]
    public Transform selector;

    private Transform target; // The red ball

    public override void OnEpisodeBegin()
    {
        envManager.ResetEnvironment();
        target = envManager.GetTarget();
    }

    /// <summary>
    /// Provides the agent with observations about the environment.
    /// </summary>
    public override void CollectObservations(VectorSensor sensor)
    {
        // For each object, provide its relative position and its color (RGB).
        // This is how the agent "sees" and recognizes the objects.
        foreach (var obj in envManager.GetSelectableObjects())
        {
            // Position relative to the agent
            sensor.AddObservation(obj.transform.position - transform.position);
            // Color information
            sensor.AddObservation(obj.color);
        }
    }

    /// <summary>
    /// Receives an action from the policy and executes it.
    /// </summary>
    public override void OnActionReceived(ActionBuffers actions)
    {
        // The discrete action corresponds to the index of the object to select.
        int objectIndex = actions.DiscreteActions[0];
        
        var selectedObject = envManager.GetSelectableObjects()[objectIndex];
        
        // Move the selector to the chosen object
        selector.position = selectedObject.transform.position;

        // --- REWARD FUNCTION ---
        if (selectedObject.transform == target)
        {
            // Big reward for selecting the correct object (the red ball)
            SetReward(1.0f);
            EndEpisode(); // End the episode on success
        }
        else
        {
            // Small penalty for selecting the wrong object
            SetReward(-0.1f);
        }
    }
    
    /// <summary>
    /// Allows for manual testing with the keyboard.
    /// </summary>
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var discreteActionsOut = actionsOut.DiscreteActions;
        if(Input.GetKeyDown(KeyCode.Alpha1)) discreteActionsOut[0] = 0;
        if(Input.GetKeyDown(KeyCode.Alpha2)) discreteActionsOut[0] = 1;
        if(Input.GetKeyDown(KeyCode.Alpha3)) discreteActionsOut[0] = 2;
        if(Input.GetKeyDown(KeyCode.Alpha4)) discreteActionsOut[0] = 3;
        if(Input.GetKeyDown(KeyCode.Alpha5)) discreteActionsOut[0] = 4;
    }
}


// ----------------- SCRIPT 2: EnvironmentManager.cs ------------------
// Attach this to a main 'EnvironmentManager' GameObject.
// It spawns and manages the objects in the scene.
// --------------------------------------------------------------------

using UnityEngine;
using System.Collections.Generic;

public class EnvironmentManager : MonoBehaviour
{
    [Header("Environment Setup")]
    public int numberOfObjects = 5;
    public GameObject area; // A plane or cube defining the spawn area
    public List<GameObject> objectPrefabs; // Sphere, Cube, Capsule, etc.

    private List<SelectableObject> selectableObjects = new List<SelectableObject>();
    private Transform target; // The red ball

    void Awake()
    {
        for (int i = 0; i < numberOfObjects; i++)
        {
            GameObject prefab = objectPrefabs[Random.Range(0, objectPrefabs.Count)];
            GameObject obj = Instantiate(prefab);
            selectableObjects.Add(obj.GetComponent<SelectableObject>());
        }
    }

    public void ResetEnvironment()
    {
        // Assign random positions and colors
        for (int i = 0; i < selectableObjects.Count; i++)
        {
            var obj = selectableObjects[i];
            obj.transform.position = GetRandomPosition();
            obj.SetColor(GetRandomColor());
        }

        // Ensure one, and only one, is the red ball (the target)
        int targetIndex = Random.Range(0, selectableObjects.Count);
        selectableObjects[targetIndex].SetColor(Color.red);
        target = selectableObjects[targetIndex].transform;
    }

    private Vector3 GetRandomPosition()
    {
        Bounds bounds = area.GetComponent<Renderer>().bounds;
        return new Vector3(
            Random.Range(bounds.min.x, bounds.max.x),
            bounds.max.y + 0.5f, // Place objects on top of the area
            Random.Range(bounds.min.z, bounds.max.z)
        );
    }

    private Color GetRandomColor()
    {
        // Generate a random color, but avoid pure red
        Color randomColor = Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f);
        while (randomColor.r > 0.9f && randomColor.g < 0.1f && randomColor.b < 0.1f)
        {
            randomColor = Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f);
        }
        return randomColor;
    }

    public List<SelectableObject> GetSelectableObjects() => selectableObjects;
    public Transform GetTarget() => target;
}


// ----------------- SCRIPT 3: SelectableObject.cs ------------------
// Attach this to each of your object prefabs (Sphere, Cube, etc.).
// A simple helper script to hold the object's color.
// ------------------------------------------------------------------

using UnityEngine;

public class SelectableObject : MonoBehaviour
{
    public Color color { get; private set; }
    private Renderer objectRenderer;

    void Awake()
    {
        objectRenderer = GetComponent<Renderer>();
    }

    public void SetColor(Color newColor)
    {
        color = newColor;
        objectRenderer.material.color = newColor;
    }
}
