// ----------------- SCRIPT 1: GenerativeAI_Controller.cs -----------------
// Attach this to a main 'GenerativeAI_Manager' GameObject.
// It orchestrates the connection between the UI, the latent variables, and the material generator.
// --------------------------------------------------------------------------

using UnityEngine;

public class GenerativeAI_Controller : MonoBehaviour
{
    [Header("References")]
    [Tooltip("The object whose material will be updated.")]
    public MaterialGenerator materialGenerator;
    [Tooltip("The UI script that provides the latent variable values.")]
    public LatentSpaceExplorer latentSpaceUI;

    [Header("Generation Parameters")]
    [Tooltip("How many latent variables the user can control.")]
    [Range(3, 8)]
    public int numberOfLatentVariables = 5;

    void Start()
    {
        if (materialGenerator == null || latentSpaceUI == null)
        {
            Debug.LogError("Controller is missing references to MaterialGenerator or LatentSpaceExplorer!");
            return;
        }

        // Initialize the UI with the correct number of sliders
        latentSpaceUI.Initialize(numberOfLatentVariables);
        
        // Register the OnLatentVariableChanged event to the GenerateTexture method
        latentSpaceUI.OnLatentVariableChanged += GenerateTexture;

        // Generate the initial texture
        GenerateTexture(latentSpaceUI.GetLatentVariables());
    }

    /// <summary>
    /// Called whenever a latent variable slider is changed in the UI.
    /// </summary>
    /// <param name="latentVariables">The array of current latent variable values.</param>
    void GenerateTexture(float[] latentVariables)
    {
        if (materialGenerator != null)
        {
            materialGenerator.GenerateTexture(latentVariables);
        }
    }

    private void OnDestroy()
    {
        // Unregister the event when the object is destroyed
        if(latentSpaceUI != null)
        {
            latentSpaceUI.OnLatentVariableChanged -= GenerateTexture;
        }
    }
}


// ----------------- SCRIPT 2: MaterialGenerator.cs ------------------
// Attach this to the 3D object you want to apply the generated texture to (e.g., a Sphere or Cube).
// It simulates the "generator" part of a VAE/GAN.
// -------------------------------------------------------------------

using UnityEngine;

public class MaterialGenerator : MonoBehaviour
{
    private Renderer objectRenderer;
    private Texture2D generatedTexture;
    private const int textureSize = 256;

    void Awake()
    {
        objectRenderer = GetComponent<Renderer>();
        if (objectRenderer == null)
        {
            Debug.LogError("MaterialGenerator requires a Renderer component on the same GameObject.");
            return;
        }

        // Create a new texture and apply it to the object's material
        generatedTexture = new Texture2D(textureSize, textureSize);
        objectRenderer.material.mainTexture = generatedTexture;
    }

    /// <summary>
    /// Generates a new texture based on the latent variable inputs.
    /// This is a SIMULATION of a generative model's output.
    /// </summary>
    /// <param name="latentVariables">An array of floats from the UI sliders.</param>
    public void GenerateTexture(float[] latentVariables)
    {
        // Use latent variables to control different aspects of the Perlin noise
        // This simulates how latent variables control features in a real VAE/GAN
        float scale = latentVariables[0] * 10f + 1f;       // Variable 0 controls overall scale
        float speed = latentVariables[1] * 2f;          // Variable 1 controls animation/shift
        float power = 1f + latentVariables[2] * 4f;       // Variable 2 controls contrast

        // Use remaining variables to influence color
        float r_influence = latentVariables.Length > 3 ? latentVariables[3] : 0.5f;
        float g_influence = latentVariables.Length > 4 ? latentVariables[4] : 0.5f;
        float b_influence = latentVariables.Length > 5 ? latentVariables[5] : 0.5f;

        for (int x = 0; x < textureSize; x++)
        {
            for (int y = 0; y < textureSize; y++)
            {
                // Calculate coordinates for Perlin noise
                float xCoord = (float)x / textureSize * scale + Time.time * speed;
                float yCoord = (float)y / textureSize * scale + Time.time * speed;

                // Generate a noise value
                float sample = Mathf.PerlinNoise(xCoord, yCoord);
                sample = Mathf.Pow(sample, power); // Apply power for contrast

                // Create a color based on the noise and color influence variables
                Color color = new Color(sample * r_influence * 2f, sample * g_influence * 2f, sample * b_influence * 2f);
                generatedTexture.SetPixel(x, y, color);
            }
        }
        generatedTexture.Apply();
    }
}


// ----------------- SCRIPT 3: LatentSpaceExplorer.cs ------------------
// Attach this to your main VR UI Canvas GameObject.
// It dynamically creates and manages the sliders for controlling the latent space.
// -----------------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;

public class LatentSpaceExplorer : MonoBehaviour
{
    [Header("UI Prefabs")]
    [Tooltip("A prefab for a UI Slider with a label.")]
    public GameObject sliderPrefab;
    [Tooltip("The container where the sliders will be instantiated.")]
    public Transform sliderContainer;

    private List<Slider> latentSliders = new List<Slider>();

    // Event that fires whenever a slider's value changes
    public event Action<float[]> OnLatentVariableChanged;

    /// <summary>
    /// Creates the UI sliders based on the requested number of variables.
    /// </summary>
    public void Initialize(int numberOfVariables)
    {
        // Clear any existing sliders
        foreach (Transform child in sliderContainer)
        {
            Destroy(child.gameObject);
        }
        latentSliders.Clear();

        for (int i = 0; i < numberOfVariables; i++)
        {
            GameObject sliderInstance = Instantiate(sliderPrefab, sliderContainer);
            sliderInstance.name = $"Latent Variable Slider {i}";
            
            Text label = sliderInstance.GetComponentInChildren<Text>();
            if (label != null)
            {
                label.text = $"Latent Var {i}";
            }

            Slider slider = sliderInstance.GetComponentInChildren<Slider>();
            if (slider != null)
            {
                slider.onValueChanged.AddListener(delegate { OnSliderValueChanged(); });
                latentSliders.Add(slider);
            }
        }
    }

    /// <summary>
    /// Called when any slider value changes. It gathers all values and invokes the event.
    /// </summary>
    private void OnSliderValueChanged()
    {
        OnLatentVariableChanged?.Invoke(GetLatentVariables());
    }

    /// <summary>
    /// Gathers the current values from all sliders.
    /// </summary>
    /// <returns>An array of floats representing the latent space vector.</returns>
    public float[] GetLatentVariables()
    {
        float[] variables = new float[latentSliders.Count];
        for (int i = 0; i < latentSliders.Count; i++)
        {
            variables[i] = latentSliders[i].value;
        }
        return variables;
    }
}
