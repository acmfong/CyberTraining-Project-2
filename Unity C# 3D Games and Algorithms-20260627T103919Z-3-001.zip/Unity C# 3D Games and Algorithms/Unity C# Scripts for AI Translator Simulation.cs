// ----------------- SCRIPT 1: TranslatorController.cs -----------------
// Attach this to a main 'TranslatorManager' GameObject.
// This is the master controller that orchestrates the translation simulation.
// ---------------------------------------------------------------------

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TranslatorController : MonoBehaviour
{
    [Header("Simulation Components")]
    public TranslationSimulator simulator;
    public VR_UI_Handler uiHandler;

    [Header("Translation Data")]
    // A simple dictionary to act as our "trained model"
    private Dictionary<string, string> translationDictionary = new Dictionary<string, string>
    {
        { "Hello how are you", "Hola como estas" },
        { "This is a test", "Esto es una prueba" },
        { "Please open the door", "Por favor abre la puerta" }
    };

    void Start()
    {
        // Pass the sentences to the UI so it can create buttons for them
        uiHandler.Initialize(new List<string>(translationDictionary.Keys), this);
    }

    /// <summary>
    /// Called by the UI when a sentence button is pressed.
    /// </summary>
    public void StartTranslation(string sentenceToTranslate)
    {
        if (simulator.IsRunning()) return;

        if (translationDictionary.TryGetValue(sentenceToTranslate, out string translatedSentence))
        {
            StartCoroutine(RunFullSimulation(sentenceToTranslate, translatedSentence));
        }
        else
        {
            Debug.LogError($"Sentence '{sentenceToTranslate}' not found in dictionary.");
        }
    }

    private IEnumerator RunFullSimulation(string source, string target)
    {
        // 1. Tokenize the input sentence
        string[] sourceTokens = source.Split(' ');
        yield return StartCoroutine(simulator.ShowTokenization(sourceTokens));

        // 2. Encode the tokens into a context vector
        yield return StartCoroutine(simulator.ShowEncoding(sourceTokens.Length));

        // 3. Decode the context vector into the output sentence, showing attention
        string[] targetTokens = target.Split(' ');
        yield return StartCoroutine(simulator.ShowDecoding(targetTokens, sourceTokens.Length));
        
        // 4. Display final subtitle on the avatar
        simulator.ShowFinalSubtitle(target);
    }
}


// ----------------- SCRIPT 2: TranslationSimulator.cs ------------------
// Attach this to a 'Simulator' GameObject in the scene.
// Manages all the visual elements and animations of the simulation.
// ----------------------------------------------------------------------

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TranslationSimulator : MonoBehaviour
{
    [Header("Scene Transforms")]
    public Transform tokenStartPosition;
    public Transform encoderPosition;
    public Transform decoderPosition;
    public Transform avatarSubtitlePosition;

    [Header("Prefabs")]
    public GameObject tokenPrefab;
    public GameObject contextVectorPrefab;
    public LineRenderer attentionLinePrefab;

    [Header("Animation Parameters")]
    public float tokenSpeed = 2.0f;
    public float processingTime = 1.0f;

    private List<GameObject> activeTokens = new List<GameObject>();
    private GameObject contextVectorInstance;
    private bool isRunning = false;

    public bool IsRunning() => isRunning;

    public IEnumerator ShowTokenization(string[] tokens)
    {
        isRunning = true;
        ClearSimulation(); // Clean up previous run

        for (int i = 0; i < tokens.Length; i++)
        {
            Vector3 pos = tokenStartPosition.position + new Vector3(i * 1.2f, 0, 0);
            GameObject tokenObj = Instantiate(tokenPrefab, pos, Quaternion.identity, transform);
            tokenObj.GetComponentInChildren<TextMesh>().text = tokens[i];
            activeTokens.Add(tokenObj);
            yield return new WaitForSeconds(0.2f);
        }
        yield return new WaitForSeconds(1.0f);
    }

    public IEnumerator ShowEncoding(int tokenCount)
    {
        // Move all tokens towards the encoder
        foreach (var token in activeTokens)
        {
            StartCoroutine(MoveObject(token, encoderPosition.position, tokenSpeed));
        }
        yield return new WaitForSeconds(1.5f); // Wait for tokens to arrive

        // Create the context vector
        contextVectorInstance = Instantiate(contextVectorPrefab, encoderPosition.position, Quaternion.identity, transform);
        yield return new WaitForSeconds(processingTime);

        // Move context vector to decoder
        StartCoroutine(MoveObject(contextVectorInstance, decoderPosition.position, tokenSpeed));
        yield return new WaitForSeconds(1.5f);
    }

    public IEnumerator ShowDecoding(string[] targetTokens, int sourceTokenCount)
    {
        // Destroy the original source tokens and the context vector
        foreach (var token in activeTokens) Destroy(token);
        activeTokens.Clear();
        if(contextVectorInstance) Destroy(contextVectorInstance);

        // Generate target tokens one by one
        for (int i = 0; i < targetTokens.Length; i++)
        {
            // Simulate Attention: draw a line from decoder to a random source token position
            int attentionIndex = Random.Range(0, sourceTokenCount);
            Vector3 sourceAttentionPos = tokenStartPosition.position + new Vector3(attentionIndex * 1.2f, 0, 0);
            
            LineRenderer line = Instantiate(attentionLinePrefab, transform);
            line.SetPosition(0, decoderPosition.position);
            line.SetPosition(1, sourceAttentionPos);
            Destroy(line.gameObject, 0.5f); // Line fades quickly

            // Create the new token
            Vector3 pos = decoderPosition.position + new Vector3(i * 1.2f, 0, 0);
            GameObject tokenObj = Instantiate(tokenPrefab, decoderPosition.position, Quaternion.identity, transform);
            tokenObj.GetComponentInChildren<TextMesh>().text = targetTokens[i];
            activeTokens.Add(tokenObj);

            StartCoroutine(MoveObject(tokenObj, pos, tokenSpeed));
            yield return new WaitForSeconds(0.6f);
        }
        yield return new WaitForSeconds(1.0f);
    }

    public void ShowFinalSubtitle(string text)
    {
        // For simplicity, we create a new text object each time.
        // A more robust solution would use a dedicated UI canvas on the avatar.
        GameObject subtitleObj = new GameObject("Subtitle");
        subtitleObj.transform.position = avatarSubtitlePosition.position;
        subtitleObj.transform.rotation = avatarSubtitlePosition.rotation;
        TextMesh textMesh = subtitleObj.AddComponent<TextMesh>();
        textMesh.text = text;
        textMesh.fontSize = 24;
        textMesh.anchor = TextAnchor.MiddleCenter;
        textMesh.color = Color.white;
        Destroy(subtitleObj, 4.0f); // Subtitle disappears after 4 seconds

        // Clean up and finish
        ClearSimulation();
        isRunning = false;
    }

    private void ClearSimulation()
    {
        foreach (var token in activeTokens) if(token) Destroy(token);
        activeTokens.Clear();
        if(contextVectorInstance) Destroy(contextVectorInstance);
    }

    private IEnumerator MoveObject(GameObject obj, Vector3 targetPos, float speed)
    {
        while (obj != null && Vector3.Distance(obj.transform.position, targetPos) > 0.1f)
        {
            obj.transform.position = Vector3.MoveTowards(obj.transform.position, targetPos, speed * Time.deltaTime);
            yield return null;
        }
        if(obj != null) obj.transform.position = targetPos;
    }
}


// ----------------- SCRIPT 3: VR_UI_Handler.cs ------------------
// Attach this to your main VR UI Canvas GameObject.
// It dynamically creates buttons for each sentence.
// -----------------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class VR_UI_Handler : MonoBehaviour
{
    [Header("UI Prefabs")]
    public GameObject buttonPrefab;
    public Transform buttonContainer;

    private TranslatorController controller;

    public void Initialize(List<string> sentences, TranslatorController controller)
    {
        this.controller = controller;
        foreach (string sentence in sentences)
        {
            GameObject buttonObj = Instantiate(buttonPrefab, buttonContainer);
            buttonObj.GetComponentInChildren<Text>().text = sentence;
            
            Button button = buttonObj.GetComponent<Button>();
            // Add a listener to call the controller when this specific button is clicked
            button.onClick.AddListener(() => OnSentenceSelected(sentence));
        }
    }

    private void OnSentenceSelected(string sentence)
    {
        Debug.Log($"UI Button clicked: {sentence}");
        controller.StartTranslation(sentence);
    }
}
