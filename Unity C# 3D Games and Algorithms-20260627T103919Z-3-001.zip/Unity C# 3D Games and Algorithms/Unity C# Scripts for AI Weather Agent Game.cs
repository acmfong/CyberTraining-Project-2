// ----------------- SCRIPT 1: WeatherAgentController.cs -----------------
// Attach this to a main 'WeatherManager' GameObject.
// This is the master controller that orchestrates the simulation.
// ---------------------------------------------------------------------

using UnityEngine;

public class WeatherAgentController : MonoBehaviour
{
    [Header("Components")]
    public WeatherSystem weatherSystem;
    public FuzzyLogicAgent agent;
    public VR_Weather_UI uiHandler;

    void Start()
    {
        uiHandler.OnNewForecastRequested += RunNewForecast;
    }

    /// <summary>
    /// Called by the UI to generate a new forecast and have the agent evaluate it.
    /// </summary>
    public void RunNewForecast()
    {
        // 1. Generate new synthetic weather data
        WeatherSystem.WeatherData data = weatherSystem.GenerateNewForecast();
        
        // 2. The agent uses fuzzy logic to make a decision
        FuzzyLogicAgent.Decision decision = agent.MakeDecision(data);

        // 3. Update the UI with the results
        uiHandler.UpdateUI(data, decision);
    }
}


// ----------------- SCRIPT 2: WeatherSystem.cs ------------------
// Attach this to a 'WeatherSystem' GameObject in the scene.
// It simulates probabilistic weather forecasting and controls visual effects.
// ---------------------------------------------------------------

using UnityEngine;

public class WeatherSystem : MonoBehaviour
{
    [Header("Visual Effects")]
    public ParticleSystem rainEffect;
    public Light sunLight;
    public Material skyMaterial; // A skybox material

    private float baseTemp = 20f; // Celsius
    private float baseWind = 10f; // kph

    // Struct to hold our weather data
    public struct WeatherData
    {
        public float temperature; // in Celsius
        public float cloudCover;  // 0.0 to 1.0
        public float windSpeed;   // in kph
    }

    /// <summary>
    /// Generates a new set of synthetic weather data. This simulates a forecast.
    /// </summary>
    public WeatherData GenerateNewForecast()
    {
        WeatherData data = new WeatherData
        {
            // The forecast is probabilistic - it's a base value plus some randomness
            temperature = baseTemp + Random.Range(-15f, 15f),
            cloudCover = Random.Range(0f, 1f),
            windSpeed = baseWind + Random.Range(-5f, 20f)
        };
        
        UpdateVisuals(data);
        return data;
    }

    /// <summary>
    /// Updates the scene's visuals to match the weather data.
    /// </summary>
    private void UpdateVisuals(WeatherData data)
    {
        // Adjust sunlight intensity and color based on clouds
        sunLight.intensity = 1.0f - (data.cloudCover * 0.8f);
        sunLight.color = Color.Lerp(Color.yellow, Color.gray, data.cloudCover);
        
        // Adjust skybox tint
        skyMaterial.SetColor("_Tint", Color.Lerp(Color.white, Color.gray, data.cloudCover));

        // Control rain particle emission
        var emission = rainEffect.emission;
        emission.rateOverTime = data.cloudCover > 0.7f ? (data.cloudCover - 0.7f) * 1000f : 0;
    }
}


// ----------------- SCRIPT 3: FuzzyLogicAgent.cs ------------------
// Attach this to the 'Agent' GameObject.
// This is the AI's brain, using fuzzy logic to make decisions.
// -----------------------------------------------------------------

using UnityEngine;

public class FuzzyLogicAgent : MonoBehaviour
{
    // Struct to hold the agent's final decision
    public struct Decision
    {
        public string recommendation;
        public Color decisionColor;
    }

    /// <summary>
    /// Makes a decision based on weather data using fuzzy logic rules.
    /// </summary>
    public Decision MakeDecision(WeatherSystem.WeatherData data)
    {
        // --- 1. Fuzzification ---
        // Convert crisp inputs (e.g., 12°C) into fuzzy values (e.g., 80% cold, 20% cool).
        float tempCold = FuzzyGrade(data.temperature, -10, 10);
        float tempWarm = FuzzyGrade(data.temperature, 15, 30);
        float cloudHeavy = FuzzyGrade(data.cloudCover, 0.6f, 1.0f);
        float windStrong = FuzzyGrade(data.windSpeed, 20, 40);

        // --- 2. Rule Evaluation ---
        // Evaluate our simple fuzzy rules. The strength of a rule is the MINIMUM of its conditions.
        float rule1_WearJacket = Mathf.Min(tempCold, 1 - cloudHeavy); // IF temp is Cold AND NOT cloud is Heavy
        float rule2_TakeUmbrella = cloudHeavy; // IF cloud is Heavy
        float rule3_WearLightly = Mathf.Min(tempWarm, 1 - windStrong); // IF temp is Warm AND NOT wind is Strong
        
        // --- 3. Defuzzification (Simplified) ---
        // Combine the rule outputs to make a crisp decision. We'll use the strongest rule.
        if (rule1_WearJacket > rule2_TakeUmbrella && rule1_WearJacket > rule3_WearLightly)
        {
            return new Decision { recommendation = "Recommendation: Wear a Jacket.", decisionColor = Color.blue };
        }
        if (rule2_TakeUmbrella > rule1_WearJacket && rule2_TakeUmbrella > rule3_WearLightly)
        {
            return new Decision { recommendation = "Recommendation: Take an Umbrella.", decisionColor = Color.cyan };
        }
        if (rule3_WearLightly > rule1_WearJacket && rule3_WearLightly > rule2_TakeUmbrella)
        {
            return new Decision { recommendation = "Recommendation: Wear Lightly.", decisionColor = Color.yellow };
        }

        return new Decision { recommendation = "Recommendation: Conditions are average.", decisionColor = Color.white };
    }

    /// <summary>
    /// A simple linear fuzzy membership function.
    /// Returns a value between 0.0 and 1.0 representing the degree of membership.
    /// </summary>
    private float FuzzyGrade(float value, float lowerBound, float upperBound)
    {
        if (value <= lowerBound) return 1.0f;
        if (value >= upperBound) return 0.0f;
        return (upperBound - value) / (upperBound - lowerBound);
    }
}


// ----------------- SCRIPT 4: VR_Weather_UI.cs ------------------
// Attach this to your main VR UI Canvas GameObject.
// Handles UI events and displays results.
// ---------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;
using System;

public class VR_Weather_UI : MonoBehaviour
{
    [Header("UI Elements")]
    public Button newForecastButton;
    public Text temperatureText;
    public Text cloudCoverText;
    public Text windSpeedText;
    public Text agentDecisionText;
    public Image decisionPanel; // A UI panel to change color based on the decision

    public event Action OnNewForecastRequested;

    void Start()
    {
        newForecastButton.onClick.AddListener(() => OnNewForecastRequested?.Invoke());
    }

    public void UpdateUI(WeatherSystem.WeatherData data, FuzzyLogicAgent.Decision decision)
    {
        temperatureText.text = $"Temperature: {data.temperature:F1}°C";
        cloudCoverText.text = $"Cloud Cover: {data.cloudCover * 100:F0}%";
        windSpeedText.text = $"Wind Speed: {data.windSpeed:F0} kph";
        agentDecisionText.text = decision.recommendation;
        decisionPanel.color = decision.decisionColor;
    }
}
