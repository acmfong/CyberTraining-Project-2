// ----------------- SCRIPT 1: RealtorAgentController.cs -----------------
// Attach this to a main 'RealtorManager' GameObject.
// This is the master controller that orchestrates the recommendation process.
// -----------------------------------------------------------------------

using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class RealtorAgentController : MonoBehaviour
{
    [Header("Components")]
    public MultiObjectiveAgent agent;
    public VR_Realtor_UI uiHandler;
    public PropertyDisplay propertyDisplay;

    private List<Property> allProperties;

    void Start()
    {
        InitializeProperties();
        agent = new MultiObjectiveAgent(allProperties);
        uiHandler.OnRecommendClicked += GetRecommendation;
    }

    // Creates our database of available real estate listings
    void InitializeProperties()
    {
        allProperties = new List<Property>
        {
            new Property("Suburban Family Home", 450000, 2200, 0.5f, 4),
            new Property("Downtown Loft", 600000, 1200, 5.0f, 2),
            new Property("Cozy Bungalow", 320000, 1500, 1.0f, 3),
            new Property("Luxury Penthouse", 1200000, 3000, 8.0f, 5),
            new Property("Starter Townhouse", 380000, 1800, 2.5f, 3),
            new Property("Countryside Villa", 800000, 4000, 0.1f, 5),
            new Property("Compact City Condo", 550000, 900, 10.0f, 1),
            new Property("Spacious Ranch", 510000, 2800, 0.8f, 4)
        };
    }

    /// <summary>
    /// Called by the UI button. Gathers preferences and asks the agent for recommendations.
    /// </summary>
    public void GetRecommendation()
    {
        // Get user preferences from the UI
        UserPreferences prefs = uiHandler.GetCurrentPreferences();
        
        // The agent uses its multi-objective analysis to find the best properties
        List<Property> recommendedProperties = agent.FindBestProperties(prefs);

        // Display the top 3 results
        propertyDisplay.ShowProperties(recommendedProperties.Take(3).ToList());
    }
}

// Helper class to hold property data
public class Property
{
    public string Name;
    public int Price;
    public int SquareFeet;
    public float ParkDistance; // in km
    public int Quality; // 1 to 5 stars
    public float Score; // Calculated by the agent

    public Property(string name, int price, int sqft, float parkDist, int quality)
    {
        Name = name; Price = price; SquareFeet = sqft; ParkDistance = parkDist; Quality = quality;
    }
}

// Helper struct to hold user preferences and weights
public struct UserPreferences
{
    public float PriceWeight;
    public float SizeWeight;
    public float ParkDistanceWeight;
    public float QualityWeight;
}


// ----------------- SCRIPT 2: MultiObjectiveAgent.cs ------------------
// This is a pure logic class, not attached to any GameObject.
// It represents the AI agent and contains the multi-criteria analysis logic.
// ---------------------------------------------------------------------

using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MultiObjectiveAgent
{
    private List<Property> knowledgeBase;

    public MultiObjectiveAgent(List<Property> properties)
    {
        knowledgeBase = properties;
    }

    /// <summary>
    /// This method performs a multi-objective optimization to rank properties.
    /// </summary>
    public List<Property> FindBestProperties(UserPreferences prefs)
    {
        // Find min/max values in the dataset for normalization
        float minPrice = knowledgeBase.Min(p => p.Price);
        float maxPrice = knowledgeBase.Max(p => p.Price);
        float minSize = knowledgeBase.Min(p => p.SquareFeet);
        float maxSize = knowledgeBase.Max(p => p.SquareFeet);
        float minParkDist = knowledgeBase.Min(p => p.ParkDistance);
        float maxParkDist = knowledgeBase.Max(p => p.ParkDistance);

        foreach (var property in knowledgeBase)
        {
            // --- Normalization ---
            // Convert each property's features to a 0-1 scale.
            // For price and distance, lower is better, so we invert the score.
            float priceScore = 1 - Mathf.InverseLerp(minPrice, maxPrice, property.Price);
            float sizeScore = Mathf.InverseLerp(minSize, maxSize, property.SquareFeet);
            float parkScore = 1 - Mathf.InverseLerp(minParkDist, maxParkDist, property.ParkDistance);
            float qualityScore = Mathf.InverseLerp(1, 5, property.Quality);

            // --- Weighted Sum ---
            // Calculate the final score based on the user's preference weights.
            property.Score = (priceScore * prefs.PriceWeight) +
                             (sizeScore * prefs.SizeWeight) +
                             (parkScore * prefs.ParkDistanceWeight) +
                             (qualityScore * prefs.QualityWeight);
        }

        // Return the list of properties, sorted by the calculated score
        return knowledgeBase.OrderByDescending(p => p.Score).ToList();
    }
}


// ----------------- SCRIPT 3: VR_Realtor_UI.cs ------------------
// Attach this to your main VR UI Canvas GameObject.
// It handles the UI sliders for setting preference weights.
// ---------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;
using System;

public class VR_Realtor_UI : MonoBehaviour
{
    [Header("UI Sliders")]
    public Slider priceSlider;
    public Slider sizeSlider;
    public Slider parkSlider;
    public Slider qualitySlider;
    public Button recommendButton;

    public event Action OnRecommendClicked;

    void Start()
    {
        recommendButton.onClick.AddListener(() => OnRecommendClicked?.Invoke());
    }

    public UserPreferences GetCurrentPreferences()
    {
        // The value of each slider (0 to 1) directly corresponds to the weight
        // the user places on that criterion.
        return new UserPreferences
        {
            PriceWeight = priceSlider.value,
            SizeWeight = sizeSlider.value,
            ParkDistanceWeight = parkSlider.value,
            QualityWeight = qualitySlider.value
        };
    }
}


// ----------------- SCRIPT 4: PropertyDisplay.cs ------------------
// Attach this to a 'DisplayManager' GameObject.
// It spawns and manages the 3D representations of the recommended properties.
// -----------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class PropertyDisplay : MonoBehaviour
{
    public GameObject propertyCardPrefab;
    public Transform[] displaySlots; // 3 empty GameObjects for positions

    private List<GameObject> activeCards = new List<GameObject>();

    public void ShowProperties(List<Property> properties)
    {
        // Clear previous results
        foreach (var card in activeCards)
        {
            Destroy(card);
        }
        activeCards.Clear();

        // Create new cards for the recommended properties
        for (int i = 0; i < properties.Count && i < displaySlots.Length; i++)
        {
            GameObject cardObj = Instantiate(propertyCardPrefab, displaySlots[i].position, displaySlots[i].rotation);
            activeCards.Add(cardObj);

            // Find the Text components on the card and populate them
            Text nameText = cardObj.transform.Find("NameText").GetComponent<Text>();
            Text detailsText = cardObj.transform.Find("DetailsText").GetComponent<Text>();
            Text scoreText = cardObj.transform.Find("ScoreText").GetComponent<Text>();

            nameText.text = properties[i].Name;
            detailsText.text = $"Price: ${properties[i].Price}\n" +
                               $"Size: {properties[i].SquareFeet} sqft\n" +
                               $"Park Dist: {properties[i].ParkDistance} km\n" +
                               $"Quality: {properties[i].Quality}/5";
            scoreText.text = $"Match Score: {properties[i].Score:F2}";
        }
    }
}
