// ----------------- SCRIPT 1: GA_Controller.cs -----------------
// Attach this to a main 'GA_Manager' GameObject.
// This is the master controller that runs the entire evolution process.
// --------------------------------------------------------------

using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class GA_Controller : MonoBehaviour
{
    [Header("GA Parameters")]
    public int populationSize = 100;
    public float mutationRate = 0.01f;
    public int dnaSize = 100; // Number of moves in a creature's lifecycle

    [Header("Scene References")]
    public CreatureController creaturePrefab;
    public Transform startPoint;
    public Transform endPoint;
    public GameObject obstaclesContainer;

    [Header("UI")]
    public UnityEngine.UI.Text generationText;
    public UnityEngine.UI.Text bestFitnessText;

    private List<CreatureController> population = new List<CreatureController>();
    private int generationNumber = 0;
    private bool isEvolving = false;

    /// <summary>
    /// Called from a VR UI Button to start the evolution.
    /// </summary>
    public void StartEvolution()
    {
        if (isEvolving) return;
        isEvolving = true;
        
        // Create the initial random population
        CreatePopulation();
        
        // Start the generation cycle
        InvokeRepeating(nameof(RunGeneration), 1.0f, dnaSize * Time.fixedDeltaTime + 1.0f);
    }

    void CreatePopulation()
    {
        for (int i = 0; i < populationSize; i++)
        {
            CreatureController creature = Instantiate(creaturePrefab, startPoint.position, Quaternion.identity);
            creature.Initialize(dnaSize, endPoint, obstaclesContainer);
            population.Add(creature);
        }
    }

    void RunGeneration()
    {
        // 1. Calculate Fitness for every creature in the current population
        foreach (var creature in population)
        {
            creature.CalculateFitness();
        }

        // 2. Create the next generation through Selection, Crossover, and Mutation
        List<CreatureController> newPopulation = new List<CreatureController>();
        
        // Sort the population by fitness, descending
        List<CreatureController> sortedPopulation = population.OrderByDescending(c => c.fitness).ToList();
        
        // Keep the top 10% (Elitism)
        int eliteCount = populationSize / 10;
        for (int i = 0; i < eliteCount; i++)
        {
            CreatureController eliteCreature = Instantiate(creaturePrefab, startPoint.position, Quaternion.identity);
            eliteCreature.Initialize(dnaSize, endPoint, obstaclesContainer, sortedPopulation[i].dna);
            newPopulation.Add(eliteCreature);
        }

        // Fill the rest of the new population
        for (int i = eliteCount; i < populationSize; i++)
        {
            // Selection (Tournament or Roulette Wheel)
            CreatureController parent1 = SelectParent(sortedPopulation);
            CreatureController parent2 = SelectParent(sortedPopulation);

            // Crossover
            DNA childDna = parent1.dna.Crossover(parent2.dna);
            
            // Mutation
            childDna.Mutate(mutationRate);

            CreatureController child = Instantiate(creaturePrefab, startPoint.position, Quaternion.identity);
            child.Initialize(dnaSize, endPoint, obstaclesContainer, childDna);
            newPopulation.Add(child);
        }

        // Destroy the old population
        foreach (var creature in population)
        {
            Destroy(creature.gameObject);
        }

        // Replace with the new generation
        population = newPopulation;
        
        generationNumber++;
        UpdateUI(sortedPopulation[0].fitness);
    }

    // Simple tournament selection
    CreatureController SelectParent(List<CreatureController> sortedPopulation)
    {
        // Select 5 random candidates and return the best one
        List<CreatureController> candidates = new List<CreatureController>();
        for(int i = 0; i < 5; i++)
        {
            candidates.Add(sortedPopulation[Random.Range(0, populationSize / 2)]); // Bias towards fitter half
        }
        return candidates.OrderByDescending(c => c.fitness).First();
    }
    
    void UpdateUI(float bestFitness)
    {
        if(generationText) generationText.text = $"Generation: {generationNumber}";
        if(bestFitnessText) bestFitnessText.text = $"Best Fitness: {bestFitness:F2}";
    }
}


// ----------------- SCRIPT 2: CreatureController.cs ------------------
// Attach this to your 'Creature' prefab.
// This class manages the creature's movement, DNA, and fitness calculation.
// ----------------------------------------------------------------------

using UnityEngine;

public class CreatureController : MonoBehaviour
{
    public DNA dna { get; private set; }
    public float fitness { get; private set; }

    private Rigidbody rb;
    private Transform goal;
    private GameObject obstacles;
    private int geneIndex = 0;
    private bool isAlive = true;
    private float distanceToGoal;

    public void Initialize(int dnaSize, Transform goal, GameObject obstacles, DNA existingDna = null)
    {
        this.goal = goal;
        this.obstacles = obstacles;
        rb = GetComponent<Rigidbody>();

        if (existingDna != null)
        {
            dna = existingDna;
        }
        else
        {
            dna = new DNA(dnaSize);
        }
    }

    void FixedUpdate()
    {
        if (!isAlive) return;

        // Apply force based on the current gene
        if (geneIndex < dna.genes.Length)
        {
            rb.AddForce(dna.genes[geneIndex] * 5f);
            geneIndex++;
        }
        else
        {
            // Lifecycle is over
            isAlive = false;
        }
    }

    void OnCollisionEnter(Collision col)
    {
        // Die if it hits an obstacle
        if (col.gameObject.transform.parent == obstacles.transform)
        {
            isAlive = false;
        }
    }

    public void CalculateFitness()
    {
        distanceToGoal = Vector3.Distance(transform.position, goal.position);
        
        // Fitness is inversely proportional to the distance to the goal
        fitness = 1 / distanceToGoal;

        // Bonus for reaching the goal
        if (distanceToGoal < 1.0f)
        {
            fitness *= 10f;
        }

        // Penalty for not being alive (hitting an obstacle)
        if (!isAlive)
        {
            fitness *= 0.1f;
        }
    }
}


// ----------------- SCRIPT 3: DNA.cs ------------------
// This is a pure logic class, not attached to any GameObject.
// It defines the genetic makeup of a creature.
// -------------------------------------------------------

using UnityEngine;

public class DNA
{
    public Vector3[] genes { get; private set; }

    public DNA(int size)
    {
        genes = new Vector3[size];
        for (int i = 0; i < size; i++)
        {
            // Each gene is a random movement vector
            genes[i] = new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)).normalized;
        }
    }

    public DNA(Vector3[] existingGenes)
    {
        genes = existingGenes;
    }

    /// <summary>
    /// Combines this DNA with a partner's DNA to create a child.
    /// </summary>
    public DNA Crossover(DNA partner)
    {
        Vector3[] childGenes = new Vector3[genes.Length];
        int midpoint = Random.Range(0, genes.Length);

        for (int i = 0; i < genes.Length; i++)
        {
            if (i < midpoint)
            {
                childGenes[i] = this.genes[i];
            }
            else
            {
                childGenes[i] = partner.genes[i];
            }
        }
        return new DNA(childGenes);
    }

    /// <summary>
    /// Randomly changes some of the genes.
    /// </summary>
    public void Mutate(float mutationRate)
    {
        for (int i = 0; i < genes.Length; i++)
        {
            if (Random.Range(0f, 1f) < mutationRate)
            {
                genes[i] = new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)).normalized;
            }
        }
    }
}
