// ----------------- SCRIPT 1: InferenceEngine.cs -----------------
// This is the "brain" of the AI. It doesn't get attached to any GameObject.
// It's a pure logic class that holds facts and rules, and can deduce new facts.
// ----------------------------------------------------------------

using System.Collections.Generic;
using System.Linq;

// Represents a single fact, e.g., "red_button_pressed"
public class Fact
{
    public string Id { get; private set; }
    public Fact(string id) { Id = id.ToLower(); }
    public override bool Equals(object obj) => obj is Fact fact && Id == fact.Id;
    public override int GetHashCode() => Id.GetHashCode();
    public override string ToString() => Id;
}

// Represents an IF-THEN rule, e.g., IF "A" and "B" are true, THEN "C" is true.
public class Rule
{
    public List<Fact> Conditions { get; private set; }
    public Fact Consequence { get; private set; }

    public Rule(List<Fact> conditions, Fact consequence)
    {
        Conditions = conditions;
        Consequence = consequence;
    }
}

public class InferenceEngine
{
    private List<Rule> ruleBase;
    private HashSet<Fact> factBase;

    public InferenceEngine()
    {
        ruleBase = new List<Rule>();
        factBase = new HashSet<Fact>();
    }

    public void AddRule(Rule rule) => ruleBase.Add(rule);
    public void AddFact(Fact fact) => factBase.Add(fact);
    public void ClearFacts() => factBase.Clear();

    /// <summary>
    /// Runs the inference process (forward chaining) to deduce all possible new facts.
    /// </summary>
    /// <returns>A list of newly deduced facts.</returns>
    public List<Fact> Infer()
    {
        List<Fact> newFacts = new List<Fact>();
        bool factsAdded;
        do
        {
            factsAdded = false;
            foreach (var rule in ruleBase)
            {
                // Check if the consequence of this rule is already a known fact
                if (factBase.Contains(rule.Consequence))
                {
                    continue;
                }

                // Check if all conditions for this rule are met by the current fact base
                bool allConditionsMet = rule.Conditions.All(condition => factBase.Contains(condition));

                if (allConditionsMet)
                {
                    // If all conditions are met, add the new fact (the consequence)
                    factBase.Add(rule.Consequence);
                    newFacts.Add(rule.Consequence);
                    factsAdded = true;
                }
            }
        } while (factsAdded); // Keep running until no new facts can be inferred in a full pass

        return newFacts;
    }
}


// ----------------- SCRIPT 2: PuzzleManager.cs ------------------
// Attach this to a 'PuzzleManager' GameObject. It sets up the puzzle
// and connects the interactive elements to the inference engine.
// ---------------------------------------------------------------

using System.Collections.Generic;
using UnityEngine;

public class PuzzleManager : MonoBehaviour
{
    [Header("Puzzle Elements")]
    public DoorController lockedDoor;
    public VR_InteractableButton redButton;
    public VR_InteractableButton blueButton;
    public VR_Pedestal greenPedestal;

    private InferenceEngine engine;
    private Fact doorUnlockedFact;

    void Start()
    {
        engine = new InferenceEngine();
        SetupRules();
        SubscribeToEvents();
    }

    void SetupRules()
    {
        // Define the facts the puzzle understands
        var redPressed = new Fact("red_button_pressed");
        var bluePressed = new Fact("blue_button_pressed");
        var itemOnPedestal = new Fact("item_on_pedestal");
        doorUnlockedFact = new Fact("door_is_unlocked");

        // Define the rule to unlock the door:
        // IF the red button is pressed AND an item is on the pedestal, THEN the door is unlocked.
        var unlockRule = new Rule(new List<Fact> { redPressed, itemOnPedestal }, doorUnlockedFact);
        
        engine.AddRule(unlockRule);
    }

    void SubscribeToEvents()
    {
        redButton.OnButtonPressed += () => OnFactChanged("red_button_pressed", true);
        redButton.OnButtonReleased += () => OnFactChanged("red_button_pressed", false);
        
        blueButton.OnButtonPressed += () => OnFactChanged("blue_button_pressed", true);
        blueButton.OnButtonReleased += () => OnFactChanged("blue_button_pressed", false);
        
        greenPedestal.OnItemPlaced += () => OnFactChanged("item_on_pedestal", true);
        greenPedestal.OnItemRemoved += () => OnFactChanged("item_on_pedestal", false);
    }
    
    private void OnFactChanged(string factId, bool isTrue)
    {
        // This is a simplified way to handle state changes.
        // A real system might have more complex fact retraction.
        // For this puzzle, we will just re-evaluate from scratch.
        EvaluatePuzzleState();
    }

    void EvaluatePuzzleState()
    {
        engine.ClearFacts();

        // Add facts based on the current state of the world
        if (redButton.IsPressed) engine.AddFact(new Fact("red_button_pressed"));
        if (blueButton.IsPressed) engine.AddFact(new Fact("blue_button_pressed"));
        if (greenPedestal.HasItem) engine.AddFact(new Fact("item_on_pedestal"));
        
        // Run the inference engine
        List<Fact> newFacts = engine.Infer();

        // Check if the goal fact was deduced
        if (newFacts.Contains(doorUnlockedFact))
        {
            Debug.Log("INFERENCE SUCCESS: 'door_is_unlocked' fact was deduced. Opening door.");
            lockedDoor.UnlockAndOpen();
        }
    }
}


// ----------------- SCRIPT 3: VR_InteractableButton.cs ------------------
// Attach this to each button GameObject in your scene.
// Makes the button physically pressable and fires events.
// -----------------------------------------------------------------------

using UnityEngine;
using UnityEngine.Events;
using System;

public class VR_InteractableButton : MonoBehaviour
{
    public event Action OnButtonPressed;
    public event Action OnButtonReleased;
    public bool IsPressed { get; private set; }

    private Vector3 startPosition;
    private float pressDepth = 0.02f; // How far the button moves down

    void Start()
    {
        startPosition = transform.localPosition;
    }

    // This would be called by a VR interaction event (e.g., from an XRGrabInteractable's Select event)
    public void Press()
    {
        if (!IsPressed)
        {
            transform.localPosition = startPosition - new Vector3(0, pressDepth, 0);
            IsPressed = true;
            OnButtonPressed?.Invoke();
            Debug.Log($"{gameObject.name} Pressed");
        }
    }

    public void Release()
    {
        if (IsPressed)
        {
            transform.localPosition = startPosition;
            IsPressed = false;
            OnButtonReleased?.Invoke();
            Debug.Log($"{gameObject.name} Released");
        }
    }
}


// ----------------- SCRIPT 4: VR_Pedestal.cs ------------------
// Attach this to a pedestal GameObject. It detects when an item is placed on it.
// -----------------------------------------------------------------------------

using UnityEngine;
using System;

public class VR_Pedestal : MonoBehaviour
{
    public event Action OnItemPlaced;
    public event Action OnItemRemoved;
    public bool HasItem { get; private set; }
    
    [Tooltip("Tag of the object that can be placed on the pedestal, e.g., 'KeyItem'")]
    public string keyItemTag = "KeyItem";

    private void OnTriggerEnter(Collider other)
    {
        if (!HasItem && other.CompareTag(keyItemTag))
        {
            HasItem = true;
            OnItemPlaced?.Invoke();
            Debug.Log($"Item '{other.name}' placed on pedestal.");
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (HasItem && other.CompareTag(keyItemTag))
        {
            HasItem = false;
            OnItemRemoved?.Invoke();
            Debug.Log($"Item '{other.name}' removed from pedestal.");
        }
    }
}


// ----------------- SCRIPT 5: DoorController.cs ------------------
// Attach this to the door GameObject.
// Handles the physical opening of the door.
// ----------------------------------------------------------------

using UnityEngine;

public class DoorController : MonoBehaviour
{
    public float openAngle = 90.0f;
    public float openSpeed = 2.0f;
    private bool isOpening = false;
    private Quaternion closedRotation;
    private Quaternion openRotation;

    void Start()
    {
        closedRotation = transform.rotation;
        openRotation = closedRotation * Quaternion.Euler(0, openAngle, 0);
    }

    void Update()
    {
        if (isOpening)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, openRotation, Time.deltaTime * openSpeed);
        }
    }

    public void UnlockAndOpen()
    {
        isOpening = true;
    }
}
