// ----------------- SCRIPT 1: PuzzleAgent.cs -----------------
// Attach this to the Agent GameObject.
// This script defines the agent's observations, actions, and rewards for the ML-Agents framework.
// ------------------------------------------------------------------------------------------------

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using System.Collections.Generic;

public class PuzzleAgent : Agent
{
    [Tooltip("The manager that controls the puzzle cube.")]
    public PuzzleManager puzzleManager;

    public override void OnEpisodeBegin()
    {
        puzzleManager.ScramblePuzzle();
    }

    /// <summary>
    /// Collects observations about the puzzle's state.
    /// The agent "sees" the type of each sub-cube (path, goal, empty).
    /// </summary>
    public override void CollectObservations(VectorSensor sensor)
    {
        List<PuzzleManager.CubeInfo> cubeStates = puzzleManager.GetCubeStates();
        foreach (var cubeInfo in cubeStates)
        {
            sensor.AddObservation((int)cubeInfo.type);
            sensor.AddObservation(cubeInfo.transform.localPosition); // Its position relative to the puzzle center
        }
    }

    /// <summary>
    /// Receives an action from the policy and executes it.
    /// </summary>
    public override void OnActionReceived(ActionBuffers actions)
    {
        // Action space: 6 axes (X, -X, Y, -Y, Z, -Z) and 3 slices per axis = 18 actions
        int action = actions.DiscreteActions[0];
        
        int axis = action / 6; // 0=X, 1=Y, 2=Z
        int slice = (action % 6) / 2;
        bool clockwise = (action % 2) == 0;

        puzzleManager.RotateFace((PuzzleManager.Axis)axis, slice, clockwise);

        // --- REWARD FUNCTION ---
        if (puzzleManager.IsPathToGoalComplete())
        {
            SetReward(1.0f); // Big reward for solving the puzzle
            EndEpisode();
        }
        else
        {
            // Small negative reward for each move to encourage minimal steps
            AddReward(-0.01f);
        }
    }
    
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var discreteActions = actionsOut.DiscreteActions;
        // Manual controls can be mapped here for testing if desired
        if (Input.GetKeyDown(KeyCode.Q)) discreteActions[0] = 0; // Rotate X, slice 0, clockwise
        if (Input.GetKeyDown(KeyCode.A)) discreteActions[0] = 1; // Rotate X, slice 0, counter-clockwise
    }
}


// ----------------- SCRIPT 2: PuzzleManager.cs ------------------
// Attach this to a 'PuzzleManager' GameObject.
// It creates, manages, and rotates the 3x3x3 cube.
// ---------------------------------------------------------------

using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class PuzzleManager : MonoBehaviour
{
    public enum Axis { X, Y, Z }
    public enum CubeType { Empty, Path, Start, Goal }

    [Header("Setup")]
    public int puzzleSize = 3;
    public GameObject cubePrefab;
    public Material emptyMat, pathMat, startMat, goalMat;

    private Transform[,,] cubes;
    private bool isRotating = false;

    void Awake()
    {
        CreatePuzzle();
    }

    void CreatePuzzle()
    {
        cubes = new Transform[puzzleSize, puzzleSize, puzzleSize];
        for (int x = 0; x < puzzleSize; x++)
        {
            for (int y = 0; y < puzzleSize; y++)
            {
                for (int z = 0; z < puzzleSize; z++)
                {
                    GameObject cube = Instantiate(cubePrefab, transform);
                    cube.transform.localPosition = new Vector3(x - 1, y - 1, z - 1);
                    cubes[x, y, z] = cube.transform;
                    
                    // Assign a default type
                    cube.AddComponent<CubeInfo>().type = CubeType.Empty;
                }
            }
        }
        // Designate a simple path
        SetCubeType(0, 1, 1, CubeType.Start);
        SetCubeType(1, 1, 1, CubeType.Path);
        SetCubeType(2, 1, 1, CubeType.Goal);
    }

    public void ScramblePuzzle()
    {
        for(int i = 0; i < 10; i++)
        {
            RotateFace((Axis)Random.Range(0,3), Random.Range(0,3), Random.value > 0.5f, true);
        }
    }

    public void RotateFace(Axis axis, int slice, bool clockwise, bool instant = false)
    {
        if (isRotating && !instant) return;
        StartCoroutine(DoRotation(axis, slice, clockwise, instant));
    }

    private IEnumerator DoRotation(Axis axis, int slice, bool clockwise, bool instant)
    {
        isRotating = true;
        float angle = clockwise ? 90f : -90f;
        Vector3 rotationAxis = Vector3.zero;
        if (axis == Axis.X) rotationAxis = Vector3.right;
        if (axis == Axis.Y) rotationAxis = Vector3.up;
        if (axis == Axis.Z) rotationAxis = Vector3.forward;

        Transform[] faceCubes = GetFaceCubes(axis, slice);
        GameObject pivot = new GameObject("Pivot");
        pivot.transform.SetParent(transform, false);
        foreach (var cube in faceCubes) cube.SetParent(pivot.transform, true);

        if (instant)
        {
            pivot.transform.Rotate(rotationAxis, angle);
        }
        else
        {
            Quaternion startRot = pivot.transform.rotation;
            Quaternion endRot = startRot * Quaternion.Euler(rotationAxis * angle);
            float t = 0;
            while (t < 1f)
            {
                pivot.transform.rotation = Quaternion.Slerp(startRot, endRot, t);
                t += Time.deltaTime * 5f; // Rotation speed
                yield return null;
            }
            pivot.transform.rotation = endRot;
        }

        foreach (var cube in faceCubes) cube.SetParent(transform, true);
        Destroy(pivot);
        UpdateCubeArray();
        isRotating = false;
    }

    private Transform[] GetFaceCubes(Axis axis, int slice)
    {
        List<Transform> face = new List<Transform>();
        for (int x = 0; x < puzzleSize; x++)
        {
            for (int y = 0; y < puzzleSize; y++)
            {
                for (int z = 0; z < puzzleSize; z++)
                {
                    if ((axis == Axis.X && x == slice) ||
                        (axis == Axis.Y && y == slice) ||
                        (axis == Axis.Z && z == slice))
                    {
                        face.Add(cubes[x, y, z]);
                    }
                }
            }
        }
        return face.ToArray();
    }

    // After rotation, the cubes are in new array positions. This re-indexes them.
    void UpdateCubeArray()
    {
        Transform[,,] newCubes = new Transform[puzzleSize, puzzleSize, puzzleSize];
        foreach(var cube in cubes)
        {
            int x = Mathf.RoundToInt(cube.localPosition.x) + 1;
            int y = Mathf.RoundToInt(cube.localPosition.y) + 1;
            int z = Mathf.RoundToInt(cube.localPosition.z) + 1;
            newCubes[x, y, z] = cube;
        }
        cubes = newCubes;
    }
    
    public bool IsPathToGoalComplete()
    {
        // Simple check for this specific puzzle: are start, path, and goal aligned on Y=1?
        return GetCubeType(0, 1, 1) == CubeType.Start &&
               GetCubeType(1, 1, 1) == CubeType.Path &&
               GetCubeType(2, 1, 1) == CubeType.Goal;
    }

    public List<CubeInfo> GetCubeStates()
    {
        List<CubeInfo> states = new List<CubeInfo>();
        foreach(var cube in cubes) states.Add(cube.GetComponent<CubeInfo>());
        return states;
    }

    private void SetCubeType(int x, int y, int z, CubeType type)
    {
        cubes[x, y, z].GetComponent<CubeInfo>().type = type;
        Material mat = emptyMat;
        if (type == CubeType.Path) mat = pathMat;
        if (type == CubeType.Start) mat = startMat;
        if (type == CubeType.Goal) mat = goalMat;
        cubes[x, y, z].GetComponent<Renderer>().material = mat;
    }
    
    private CubeType GetCubeType(int x, int y, int z)
    {
        return cubes[x,y,z].GetComponent<CubeInfo>().type;
    }
    
    // Helper component to store data on each cube
    public class CubeInfo : MonoBehaviour
    {
        public CubeType type;
    }
}
