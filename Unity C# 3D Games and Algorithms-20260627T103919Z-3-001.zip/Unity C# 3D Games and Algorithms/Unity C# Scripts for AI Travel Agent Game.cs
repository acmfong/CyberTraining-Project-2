// ----------------- SCRIPT 1: TravelAgentController.cs -----------------
// Attach this to a main 'TravelAgentManager' GameObject.
// This is the master controller that orchestrates the process.
// --------------------------------------------------------------------

using UnityEngine;
using System.Collections.Generic;

public class TravelAgentController : MonoBehaviour
{
    [Header("Components")]
    public DecisionTreeAgent agent;
    public VR_Travel_UI uiHandler;
    public DestinationDisplay destinationDisplay;

    private List<Destination> allDestinations;

    void Start()
    {
        InitializeDestinations();
        agent = new DecisionTreeAgent(allDestinations);
        uiHandler.OnPlanTripClicked += PlanTrip;
    }

    // Creates our database of possible travel destinations
    void InitializeDestinations()
    {
        allDestinations = new List<Destination>
        {
            new Destination("Paris", 3000, "Culture", "Luxury"),
            new Destination("Bali", 1500, "Beach", "Budget"),
            new Destination("Tokyo", 4000, "Culture", "Luxury"),
            new Destination("Phuket", 1200, "Beach", "Budget"),
            new Destination("Rome", 2800, "Culture", "Mid-Range"),
            new Destination("Costa Rica", 2200, "Adventure", "Mid-Range"),
            new Destination("New Zealand", 5000, "Adventure", "Luxury"),
            new Destination("Egypt", 2500, "History", "Mid-Range")
        };
    }

    /// <summary>
    /// Called by the UI button. Gathers preferences and asks the agent for a recommendation.
    /// </summary>
    public void PlanTrip()
    {
        // Get user preferences from the UI
        UserPreferences prefs = uiHandler.GetCurrentPreferences();
        
        // The agent uses its decision tree to find the best destination
        Destination recommendedDestination = agent.FindBestDestination(prefs);

        // Display the result
        destinationDisplay.ShowDestination(recommendedDestination);
    }
}

// Helper class to hold destination data
public class Destination
{
    public string Name;
    public int Cost;
    public string Interest; // e.g., "Beach", "Culture", "Adventure"
    public string Style;    // e.g., "Budget", "Mid-Range", "Luxury"

    public Destination(string name, int cost, string interest, string style)
    {
        Name = name; Cost = cost; Interest = interest; Style = style;
    }
}

// Helper struct to hold user preferences
public struct UserPreferences
{
    public int MaxBudget;
    public string DesiredInterest;
    public string DesiredStyle;
}


// ----------------- SCRIPT 2: DecisionTreeAgent.cs ------------------
// This is a pure logic class, not attached to any GameObject.
// It represents the AI agent and contains the decision-making logic.
// -------------------------------------------------------------------

using System.Collections.Generic;
using System.Linq;

public class DecisionTreeAgent
{
    private List<Destination> knowledgeBase;

    public DecisionTreeAgent(List<Destination> destinations)
    {
        knowledgeBase = destinations;
    }

    /// <summary>
    /// This method simulates a decision tree to filter destinations.
    /// It applies a series of constraints to find the best match.
    /// </summary>
    public Destination FindBestDestination(UserPreferences prefs)
    {
        // Start with all possible destinations
        IEnumerable<Destination> potentialDestinations = knowledgeBase;

        // --- Decision Node 1: Filter by Interest (Constraint 1) ---
        potentialDestinations = potentialDestinations.Where(d => d.Interest == prefs.DesiredInterest);

        // --- Decision Node 2: Filter by Style (Constraint 2) ---
        potentialDestinations = potentialDestinations.Where(d => d.Style == prefs.DesiredStyle);

        // --- Decision Node 3: Filter by Budget (Constraint 3) ---
        potentialDestinations = potentialDestinations.Where(d => d.Cost <= prefs.MaxBudget);

        // From the remaining valid options, pick the one that is closest to the budget without going over.
        // This is the final step in the decision process.
        return potentialDestinations.OrderByDescending(d => d.Cost).FirstOrDefault();
    }
}


// ----------------- SCRIPT 3: VR_Travel_UI.cs ------------------
// Attach this to your main VR UI Canvas GameObject.
// It handles the UI toggles, sliders, and buttons.
// --------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;
using System;

public class VR_Travel_UI : MonoBehaviour
{
    [Header("UI Elements")]
    public Slider budgetSlider;
    public Text budgetText;
    public ToggleGroup interestGroup;
    public ToggleGroup styleGroup;
    public Button planTripButton;

    public event Action OnPlanTripClicked;

    void Start()
    {
        planTripButton.onClick.AddListener(() => OnPlanTripClicked?.Invoke());
        budgetSlider.onValueChanged.AddListener(UpdateBudgetText);
        UpdateBudgetText(budgetSlider.value);
    }

    void UpdateBudgetText(float value)
    {
        budgetText.text = $"Max Budget: ${value:F0}";
    }

    public UserPreferences GetCurrentPreferences()
    {
        UserPreferences prefs = new UserPreferences();
        prefs.MaxBudget = (int)budgetSlider.value;
        
        // Find the active toggle in each group
        foreach (var toggle in interestGroup.ActiveToggles())
        {
            prefs.DesiredInterest = toggle.GetComponentInChildren<Text>().text;
            break;
        }
        foreach (var toggle in styleGroup.ActiveToggles())
        {
            prefs.DesiredStyle = toggle.GetComponentInChildren<Text>().text;
            break;
        }
        
        Debug.Log($"Prefs: Budget <= {prefs.MaxBudget}, Interest: {prefs.DesiredInterest}, Style: {prefs.DesiredStyle}");
        return prefs;
    }
}


// ----------------- SCRIPT 4: DestinationDisplay.cs ------------------
// Attach this to a 3D object in the scene (e.g., a screen or panel)
// that will display the final recommended destination.
// --------------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;

public class DestinationDisplay : MonoBehaviour
{
    public Text destinationNameText;
    public Text detailsText;
    public GameObject displayPanel; // The parent panel to show/hide

    void Start()
    {
        displayPanel.SetActive(false);
    }

    public void ShowDestination(Destination dest)
    {
        displayPanel.SetActive(true);
        if (dest != null)
        {
            destinationNameText.text = dest.Name;
            detailsText.text = $"Interest: {dest.Interest}\n" +
                               $"Style: {dest.Style}\n" +
                               $"Cost: ${dest.Cost}";
        }
        else
        {
            destinationNameText.text = "No Match Found";
            detailsText.text = "No destination meets all your criteria.\nPlease try different preferences.";
        }
    }
}
