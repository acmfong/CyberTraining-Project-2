// ----------------- SCRIPT 1: SearchController.cs -----------------
// Attach this to a main 'SearchManager' GameObject.
// This is the master controller that orchestrates the pathfinding process.
// -----------------------------------------------------------------

using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class SearchController : MonoBehaviour
{
    public enum SearchAlgorithm { AStar, BFS, DFS }

    [Header("Components")]
    public GridManager gridManager;
    public AgentVisualizer agentVisualizer;
    public VR_UI_Handler uiHandler;

    private Node startNode;
    private Node endNode;
    private SearchAlgorithm currentAlgorithm = SearchAlgorithm.AStar;

    void Start()
    {
        gridManager.OnGridCreated += InitializeSearch;
        uiHandler.OnAlgorithmChanged += SetAlgorithm;
        uiHandler.OnSearchStarted += RunSearch;
    }

    void InitializeSearch()
    {
        // Set default start and end nodes
        startNode = gridManager.GetNode(1, 1);
        endNode = gridManager.GetNode(gridManager.width - 2, gridManager.height - 2);
        gridManager.SetStartNode(startNode);
        gridManager.SetEndNode(endNode);
    }

    public void SetStartNode(Node node) => startNode = node;
    public void SetEndNode(Node node) => endNode = node;
    public void SetAlgorithm(SearchAlgorithm algorithm) => currentAlgorithm = algorithm;

    public void RunSearch()
    {
        if (agentVisualizer.IsRunning()) return;

        gridManager.ClearAllHighlights();

        List<Node> path = new List<Node>();
        switch (currentAlgorithm)
        {
            case SearchAlgorithm.AStar:
                path = Pathfinder.AStarSearch(startNode, endNode);
                break;
            case SearchAlgorithm.BFS:
                path = Pathfinder.BFS(startNode, endNode);
                break;
            case SearchAlgorithm.DFS:
                path = Pathfinder.DFS(startNode, endNode);
                break;
        }

        StartCoroutine(VisualizeSearch(Pathfinder.visitedNodes, path));
    }

    IEnumerator VisualizeSearch(List<Node> visited, List<Node> path)
    {
        // First, visualize the nodes the algorithm explored
        foreach (var node in visited)
        {
            if (node != startNode && node != endNode)
            {
                gridManager.HighlightNode(node, gridManager.exploredMaterial);
                yield return new WaitForSeconds(0.01f);
            }
        }

        // Then, move the agent along the final path
        if (path != null && path.Count > 0)
        {
            agentVisualizer.MoveAlongPath(path);
        }
        else
        {
            Debug.Log("No path found!");
        }
    }
}


// ----------------- SCRIPT 2: GridManager.cs ------------------
// Attach this to a 'Grid' GameObject.
// It procedurally generates the 3D grid of nodes.
// -------------------------------------------------------------

using UnityEngine;
using System;
using System.Collections.Generic;

public class GridManager : MonoBehaviour
{
    [Header("Grid Settings")]
    public int width = 20;
    public int height = 20;
    public float nodeSize = 1f;

    [Header("Prefabs & Materials")]
    public GameObject nodePrefab;
    public Material defaultMaterial;
    public Material obstacleMaterial;
    public Material startMaterial;
    public Material endMaterial;
    public Material pathMaterial;
    public Material exploredMaterial;

    private Node[,] grid;
    public event Action OnGridCreated;

    void Start()
    {
        CreateGrid();
    }

    void CreateGrid()
    {
        grid = new Node[width, height];
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                Vector3 worldPos = new Vector3(x * nodeSize, 0, y * nodeSize);
                GameObject obj = Instantiate(nodePrefab, worldPos, Quaternion.identity, transform);
                obj.name = $"Node_{x}_{y}";
                grid[x, y] = obj.GetComponent<Node>();
                grid[x, y].Initialize(x, y, true, worldPos, this);
            }
        }
        OnGridCreated?.Invoke();
    }

    public Node GetNode(int x, int y)
    {
        if (x >= 0 && x < width && y >= 0 && y < height)
        {
            return grid[x, y];
        }
        return null;
    }

    public List<Node> GetNeighbors(Node node)
    {
        List<Node> neighbors = new List<Node>();
        for (int x = -1; x <= 1; x++)
        {
            for (int y = -1; y <= 1; y++)
            {
                if (Mathf.Abs(x) == Mathf.Abs(y)) continue; // No diagonals

                int checkX = node.gridX + x;
                int checkY = node.gridY + y;
                
                Node neighbor = GetNode(checkX, checkY);
                if (neighbor != null && neighbor.isWalkable)
                {
                    neighbors.Add(neighbor);
                }
            }
        }
        return neighbors;
    }

    public void SetStartNode(Node node) => HighlightNode(node, startMaterial);
    public void SetEndNode(Node node) => HighlightNode(node, endMaterial);
    public void HighlightNode(Node node, Material mat) => node.GetComponent<Renderer>().material = mat;
    public void ClearAllHighlights()
    {
        foreach(var node in grid)
        {
            if(node.isWalkable) HighlightNode(node, defaultMaterial);
        }
    }
}


// ----------------- SCRIPT 3: Node.cs ------------------
// Attach this to the 'Node' prefab.
// Represents a single point in the grid.
// ----------------------------------------------------

using UnityEngine;

public class Node : MonoBehaviour
{
    public int gridX, gridY;
    public bool isWalkable;
    public Vector3 worldPosition;
    
    // Pathfinding variables
    public int gCost, hCost;
    public Node parent;
    
    private GridManager gridManager;

    public int fCost { get { return gCost + hCost; } }

    public void Initialize(int x, int y, bool walkable, Vector3 pos, GridManager manager)
    {
        gridX = x; gridY = y; isWalkable = walkable; worldPosition = pos; gridManager = manager;
    }

    public void ToggleObstacle()
    {
        isWalkable = !isWalkable;
        gridManager.HighlightNode(this, isWalkable ? gridManager.defaultMaterial : gridManager.obstacleMaterial);
    }
}


// ----------------- SCRIPT 4: Pathfinder.cs ------------------
// A static class containing the search algorithms. Does not get attached to any object.
// ------------------------------------------------------------

using System.Collections.Generic;
using System.Linq;

public static class Pathfinder
{
    public static List<Node> visitedNodes; // To visualize the search area

    public static List<Node> AStarSearch(Node start, Node end)
    {
        visitedNodes = new List<Node>();
        List<Node> openSet = new List<Node>();
        HashSet<Node> closedSet = new HashSet<Node>();
        openSet.Add(start);

        while (openSet.Count > 0)
        {
            Node currentNode = openSet[0];
            for (int i = 1; i < openSet.Count; i++)
            {
                if (openSet[i].fCost < currentNode.fCost || (openSet[i].fCost == currentNode.fCost && openSet[i].hCost < currentNode.hCost))
                {
                    currentNode = openSet[i];
                }
            }

            openSet.Remove(currentNode);
            closedSet.Add(currentNode);
            visitedNodes.Add(currentNode);

            if (currentNode == end) return RetracePath(start, end);

            foreach (var neighbor in currentNode.gridManager.GetNeighbors(currentNode))
            {
                if (!neighbor.isWalkable || closedSet.Contains(neighbor)) continue;

                int newMovementCostToNeighbor = currentNode.gCost + GetDistance(currentNode, neighbor);
                if (newMovementCostToNeighbor < neighbor.gCost || !openSet.Contains(neighbor))
                {
                    neighbor.gCost = newMovementCostToNeighbor;
                    neighbor.hCost = GetDistance(neighbor, end);
                    neighbor.parent = currentNode;

                    if (!openSet.Contains(neighbor)) openSet.Add(neighbor);
                }
            }
        }
        return null; // No path found
    }

    public static List<Node> BFS(Node start, Node end)
    {
        visitedNodes = new List<Node>();
        Queue<Node> queue = new Queue<Node>();
        HashSet<Node> visited = new HashSet<Node>();
        queue.Enqueue(start);
        visited.Add(start);

        while (queue.Count > 0)
        {
            Node currentNode = queue.Dequeue();
            visitedNodes.Add(currentNode);

            if (currentNode == end) return RetracePath(start, end);

            foreach (var neighbor in currentNode.gridManager.GetNeighbors(currentNode))
            {
                if (!visited.Contains(neighbor))
                {
                    visited.Add(neighbor);
                    neighbor.parent = currentNode;
                    queue.Enqueue(neighbor);
                }
            }
        }
        return null; // No path found
    }

    public static List<Node> DFS(Node start, Node end)
    {
        visitedNodes = new List<Node>();
        Stack<Node> stack = new Stack<Node>();
        HashSet<Node> visited = new HashSet<Node>();
        stack.Push(start);

        while (stack.Count > 0)
        {
            Node currentNode = stack.Pop();
            if (visited.Contains(currentNode)) continue;
            
            visited.Add(currentNode);
            visitedNodes.Add(currentNode);
            currentNode.parent = currentNode.parent; // This needs better parent tracking for DFS path

            if (currentNode == end) return RetracePath(start, end); // Path retracing is tricky with this simple DFS

            foreach (var neighbor in currentNode.gridManager.GetNeighbors(currentNode).AsEnumerable().Reverse())
            {
                if (!visited.Contains(neighbor))
                {
                    neighbor.parent = currentNode;
                    stack.Push(neighbor);
                }
            }
        }
        return null;
    }

    private static List<Node> RetracePath(Node startNode, Node endNode)
    {
        List<Node> path = new List<Node>();
        Node currentNode = endNode;
        while (currentNode != startNode)
        {
            path.Add(currentNode);
            currentNode = currentNode.parent;
        }
        path.Reverse();
        return path;
    }

    private static int GetDistance(Node a, Node b)
    {
        int distX = Mathf.Abs(a.gridX - b.gridX);
        int distY = Mathf.Abs(a.gridY - b.gridY);
        return distX + distY; // Manhattan distance
    }
}


// ----------------- SCRIPT 5: AgentVisualizer.cs ------------------
// Attach this to your 'Agent' prefab.
// Moves the agent model along the calculated path.
// -----------------------------------------------------------------

using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class AgentVisualizer : MonoBehaviour
{
    public float speed = 5.0f;
    private bool isRunning = false;

    public bool IsRunning() => isRunning;

    public void MoveAlongPath(List<Node> path)
    {
        if (path == null || path.Count == 0) return;
        StartCoroutine(FollowPath(path));
    }

    IEnumerator FollowPath(List<Node> path)
    {
        isRunning = true;
        transform.position = path[0].worldPosition + Vector3.up * 0.5f;

        foreach (var node in path)
        {
            Vector3 targetPos = node.worldPosition + Vector3.up * 0.5f;
            while (Vector3.Distance(transform.position, targetPos) > 0.01f)
            {
                transform.position = Vector3.MoveTowards(transform.position, targetPos, speed * Time.deltaTime);
                yield return null;
            }
        }
        isRunning = false;
    }
}

// ----------------- SCRIPT 6: VR_UI_Handler.cs ------------------
// Attach this to your main VR UI Canvas GameObject.
// Handles UI events for changing algorithms and starting the search.
// -------------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;
using System;

public class VR_UI_Handler : MonoBehaviour
{
    [Header("UI Elements")]
    public Button aStarButton;
    public Button bfsButton;
    public Button dfsButton;
    public Button startSearchButton;

    public event Action<SearchController.SearchAlgorithm> OnAlgorithmChanged;
    public event Action OnSearchStarted;

    void Start()
    {
        aStarButton.onClick.AddListener(() => OnAlgorithmChanged?.Invoke(SearchController.SearchAlgorithm.AStar));
        bfsButton.onClick.AddListener(() => OnAlgorithmChanged?.Invoke(SearchController.SearchAlgorithm.BFS));
        dfsButton.onClick.AddListener(() => OnAlgorithmChanged?.Invoke(SearchController.SearchAlgorithm.DFS));
        startSearchButton.onClick.AddListener(() => OnSearchStarted?.Invoke());
    }
}
