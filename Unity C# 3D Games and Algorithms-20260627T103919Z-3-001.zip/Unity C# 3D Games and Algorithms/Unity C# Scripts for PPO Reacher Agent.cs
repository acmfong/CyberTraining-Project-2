// ----------------- SCRIPT 1: ReacherAgent.cs -----------------
// Attach this to the parent GameObject of your articulated agent (e.g., the base of the arm).
// This script defines the agent's observations, actions, and rewards for the ML-Agents framework.
// ------------------------------------------------------------------------------------------------

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

public class ReacherAgent : Agent
{
    [Header("Agent Body Parts")]
    [Tooltip("The main arm/body of the agent.")]
    public Rigidbody armRigidbody;
    [Tooltip("The hand or end-effector that needs to reach the target.")]
    public Transform hand;
    
    [Header("Target")]
    [Tooltip("The target the agent will try to reach.")]
    public Transform target;

    private Vector3 initialArmPosition;
    private Quaternion initialArmRotation;

    public override void Initialize()
    {
        initialArmPosition = armRigidbody.transform.position;
        initialArmRotation = armRigidbody.transform.rotation;
    }

    /// <summary>
    /// Called at the beginning of each training episode. Resets the agent and environment.
    /// </summary>
    public override void OnEpisodeBegin()
    {
        // Reset the arm's position and velocity
        armRigidbody.transform.position = initialArmPosition;
        armRigidbody.transform.rotation = initialArmRotation;
        armRigidbody.velocity = Vector3.zero;
        armRigidbody.angularVelocity = Vector3.zero;
    }

    /// <summary>
    /// Collects the observations the agent needs to make a decision.
    /// This is the "State" information for the PPO algorithm.
    /// </summary>
    public override void CollectObservations(VectorSensor sensor)
    {
        // Observe the position of the target relative to the hand
        sensor.AddObservation(target.position - hand.position);

        // Observe the hand's current velocity
        sensor.AddObservation(armRigidbody.velocity);
        
        // Observe the arm's rotation
        sensor.AddObservation(armRigidbody.transform.rotation);
    }

    /// <summary>
    /// Receives actions from the policy and applies them to the agent.
    /// </summary>
    public override void OnActionReceived(ActionBuffers actions)
    {
        // Actions are continuous values (-1 to 1) representing torque to apply
        float torqueX = actions.ContinuousActions[0];
        float torqueZ = actions.ContinuousActions[1];

        // Apply torque to the rigidbody to move the arm
        armRigidbody.AddTorque(transform.right * torqueX * 100f);
        armRigidbody.AddTorque(transform.forward * torqueZ * 100f);

        // --- REWARD FUNCTION ---
        float distanceToTarget = Vector3.Distance(hand.position, target.position);

        // Reward for being close to the target
        // The closer the agent gets, the higher the reward
        AddReward(1.0f / (1.0f + distanceToTarget * distanceToTarget));

        // Small negative reward for existing, to encourage speed
        AddReward(-0.001f);

        // Check if the hand has reached the target
        if (distanceToTarget < 0.5f)
        {
            SetReward(10.0f); // Big reward for reaching the goal
            EndEpisode(); // End the episode successfully
        }
    }

    /// <summary>
    /// Allows for manual testing of the agent using keyboard controls.
    /// </summary>
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var continuousActionsOut = actionsOut.ContinuousActions;
        continuousActionsOut[0] = Input.GetAxis("Vertical");
        continuousActionsOut[1] = -Input.GetAxis("Horizontal");
    }
}


// ----------------- SCRIPT 2: EnvironmentConfigurator.cs ------------------
// Attach this to a 'VR_UI_Manager' GameObject.
// It allows the VR user to change environment parameters like gravity and target position.
// -------------------------------------------------------------------------

using UnityEngine;
using UnityEngine.UI;

public class EnvironmentConfigurator : MonoBehaviour
{
    [Header("Environment Control")]
    [Tooltip("The target object for the ReacherAgent.")]
    public Transform reacherTarget;
    [Tooltip("A slider to control the scene's gravity.")]
    public Slider gravitySlider;
    [Tooltip("A slider to control the target's height.")]
    public Slider targetHeightSlider;

    private Vector3 initialTargetPosition;

    void Start()
    {
        if (reacherTarget != null)
        {
            initialTargetPosition = reacherTarget.position;
        }

        if (gravitySlider != null)
        {
            gravitySlider.onValueChanged.AddListener(SetGravity);
            gravitySlider.value = 1.0f; // Default to normal gravity
        }

        if (targetHeightSlider != null)
        {
            targetHeightSlider.onValueChanged.AddListener(SetTargetHeight);
        }
    }

    /// <summary>
    /// Sets the world gravity based on the slider value.
    /// </summary>
    public void SetGravity(float sliderValue)
    {
        // Slider value from 0 to 1 maps to gravity multiplier from 0.1 to 2.0
        float gravityMultiplier = 0.1f + sliderValue * 1.9f;
        Physics.gravity = new Vector3(0, -9.81f * gravityMultiplier, 0);
    }

    /// <summary>
    /// Sets the target's height based on the slider value.
    /// </summary>
    public void SetTargetHeight(float sliderValue)
    {
        if (reacherTarget != null)
        {
            // Slider value from 0 to 1 maps to height offset
            Vector3 newPos = initialTargetPosition;
            newPos.y += sliderValue * 2.0f; // Adjust height by up to 2 units
            reacherTarget.position = newPos;
        }
    }
}


// ----------------- SCRIPT 3: TargetRandomizer.cs ------------------
// Attach this to the Target GameObject.
// It moves the target to a new random position at the start of each episode.
// --------------------------------------------------------------------

using UnityEngine;
using Unity.MLAgents;

public class TargetRandomizer : MonoBehaviour
{
    [Tooltip("The agent this target is associated with.")]
    public Agent agent;
    
    private void Start()
    {
        // Subscribe to the agent's event
        if (agent != null)
        {
            agent.AgentReset += MoveTargetToRandomPosition;
        }
    }

    private void OnDestroy()
    {
        if (agent != null)
        {
            agent.AgentReset -= MoveTargetToRandomPosition;
        }
    }

    /// <summary>
    /// Moves the target to a new random position within a defined area.
    /// </summary>
    void MoveTargetToRandomPosition()
    {
        transform.position = new Vector3(Random.Range(-2f, 2f), 
                                         Random.Range(1f, 3f), 
                                         Random.Range(-2f, 2f)) 
                                         + agent.transform.position;
    }
}
